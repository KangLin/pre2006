/*
 * Copyright (c) 2006 CACE Technologies, Davis (California)
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 * 3. Neither the name CACE Technologies nor the names of its contributors 
 * may be used to endorse or promote products derived from this software 
 * without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include "stdafx.h"
#include <afxtempl.h>
#include "AirpcapConf.h"
#include "AirpcapConfDlg.h"
#include "airpcap.h"
#include "Constants.h"
#include "DlgWepKey.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAirpcapConfDlg dialog

CAirpcapConfDlg::CAirpcapConfDlg(CWnd* pParent)
	: CDialog(CAirpcapConfDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CAirpcapConfDlg)
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32

	m_hIcon = AfxGetApp()->LoadIcon(IDI_ICON1);
	m_AdaptersList = new AdapterIdentifier[MAX_ADAPTERS];
	m_nAdapters = 0;
	m_IsLedBlinking = FALSE;
	m_NeedToSave = FALSE;
	m_AdNumber = 0;
	m_BufSize = 0xffffffff;
	m_LastErr = "";
}

CAirpcapConfDlg::~CAirpcapConfDlg()
{
	delete []m_AdaptersList;
}

void CAirpcapConfDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAirpcapConfDlg)
	DDX_Control(pDX, IDC_CHECK_WEP, m_CheckWepEnabled);
	DDX_Control(pDX, IDC_COMBO_FRAMESTOACCEPT, m_ComboFramesToAccpet);
	DDX_Control(pDX, IDC_BUTTON_LED, m_ButtonLedBlinking);
	DDX_Control(pDX, IDC_LIST_WEPKEYS, m_ListKeys);
	DDX_Control(pDX, IDC_CHECK_FCS, m_CheckFcs);
	DDX_Control(pDX, IDC_COMBO_LINKLAYER, m_ComboLinkLayer);
	DDX_Control(pDX, IDC_COMBO_CHANNEL, m_ComboChannel);
	DDX_Control(pDX, IDC_COMBO1, m_InterfacesCombo);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAirpcapConfDlg, CDialog)
	//{{AFX_MSG_MAP(CAirpcapConfDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_CLOSE()
	ON_CBN_SELCHANGE(IDC_COMBO_INTERFACES, OnChangeInterface)
	ON_BN_CLICKED(ID_BUTTON_APPLY, OnApply)
	ON_BN_CLICKED(IDC_BUTTON3, OnAddKey)
	ON_BN_CLICKED(IDC_BUTTON4, OnRemoveKey)
	ON_BN_CLICKED(IDC_BUTTON7, OnEditKey)
	ON_BN_CLICKED(IDC_BUTTON5, OnMoveKeyUp)
	ON_BN_CLICKED(IDC_BUTTON6, OnMoveKeyDown)
	ON_BN_CLICKED(IDC_BUTTON1, OnBlinkLed)
	ON_BN_CLICKED(IDOK3, OnOk)
	ON_BN_CLICKED(IDOK4, OnReset)
	ON_BN_CLICKED(IDOK5, OnHelp)
	ON_CBN_SELCHANGE(IDC_COMBO_CHANNEL, OnChangeChannel)
	ON_CBN_SELCHANGE(IDC_COMBO_LINKLAYER, OnChangeLinkLayer)
	ON_BN_CLICKED(IDC_CHECK_FCS, OnChangeCrcInclusion)
	ON_BN_CLICKED(IDC_CHECK_FCSVALIDATION, OnChangeCrcCalculation)
	ON_CBN_DROPDOWN(IDC_COMBO_INTERFACES, OnDropdownComboInterfaces)
	ON_CBN_SELCHANGE(IDC_COMBO_FRAMESTOACCEPT, OnSelchangeComboFramestoaccept)
	ON_BN_CLICKED(IDC_CHECK_WEP, OnChangeWepOperation)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAirpcapConfDlg message handlers

BOOL CAirpcapConfDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon	
	
	//
	// Make the encryption keys list control full-row selecatble
	//
	DWORD Styles = m_ListKeys.GetExtendedStyle();
	Styles |= LVS_EX_FULLROWSELECT;
	m_ListKeys.SetExtendedStyle(Styles);

	//
	// Fill the adapters list
	//
	UINT FalRes;
	
	while(TRUE)
	{
		FalRes = FillAdapterList();
		
		if(FalRes == FAL_ERROR)
		{
			//
			// An error occurred, print a message and exit
			//
			MessageBox("Error retrieving the list of the airpcap adapters");
			exit(0);
		}
		else if(FalRes == FAL_NO_ADAPTERS)
		{
			//
			// No adapters. Loop unil the user either plugs one or decides to exit
			//
			if(MessageBox("No AirPcap Adapters found in this system.\n\nPlease make sure that:\n - the adapter is properly connected to a USB port\n - The 'Add New Hardware Wizard' has been run succesfully\n\nClick 'Yes' to perform the detection again, 'No' to exit.", 
				"No Adapters Found",
				MB_YESNO) == IDNO)
			{
				exit(0);
			}			
		}
		else
		{
			return TRUE;
		}
	}
}

UINT CAirpcapConfDlg::FillAdapterList()
{
	UINT i;
	UINT Nadapts;
	AirpcapDeviceDescription *DevsList, *AdListEntry;
	CHAR Ebuf[AIRPCAP_ERRBUF_SIZE];

	//
	// Clear the adapters list before filling it
	//
	for(i = 0; i < MAX_ADAPTERS; i++)
	{
		m_AdaptersList[i].Name = "";
		m_AdaptersList[i].Description = "";
		m_AdaptersList[i].OriginalChannel = 15;
	}

	m_nAdapters = 0;

	//
	// Clear the combobox
	//
	m_InterfacesCombo.ResetContent();

	//
	// Get the list of adapters
	//
	if(!AirpcapGetDeviceList(&DevsList, Ebuf))
	{
		// Error getting the interfaces list, return
		return FAL_ERROR;
	}

	//
	// Count the adapters
	//
	AdListEntry = DevsList;
	Nadapts = 0;
	while(AdListEntry)
	{
		Nadapts++;
		AdListEntry = AdListEntry->next;
	}

	if(Nadapts == 0)
	{
		// No interfaces, return
		AirpcapFreeDeviceList(DevsList);
		return FAL_NO_ADAPTERS;
	}

	//
	// Insert the adapters in our list
	//
	AdListEntry = DevsList;
	for(i = 0; i < Nadapts; i++)
	{
		//
		// NOTE: we put them in the reverse order because AirpcapGetDevices gives us the last first
		//
		m_AdaptersList[Nadapts - i - 1].Name = AdListEntry->Name;
		m_AdaptersList[Nadapts - i - 1].Description = AdListEntry->Description;
		m_nAdapters++;

		AdListEntry = AdListEntry->next;
	}

	AirpcapFreeDeviceList(DevsList);

	for(i = 0; i < m_nAdapters; i++)
	{
		m_InterfacesCombo.InsertString(-1, m_AdaptersList[i].Description);
	}
	m_InterfacesCombo.SetCurSel(0);
	
	if(!FillAdapterDetails(m_AdaptersList[0].Name))
	{
		MessageBox(m_LastErr);
		return FAL_ERROR;
	}
	
	return FAL_SUCCESS;
}

void CAirpcapConfDlg::OnChangeInterface() 
{
	INT NewAdNumber = m_InterfacesCombo.GetCurSel();
	CString s;

	if(NewAdNumber != m_AdNumber)
	{
		if(m_NeedToSave)
		{
			if(MessageBox("Do you want to save the changes before switching to the new adapter?", 
				"Changes not saved",
				MB_YESNO) == IDYES)
			{
				if(!WriteDownAdapterDetails(m_AdaptersList[m_AdNumber].Name))
				{
					s = "Unable to save the properties for the selected adapter:\n";
					s += m_LastErr;
					MessageBox(s, "Save error", MB_OK | MB_ICONERROR);
				}
			}
		}
		
		//
		// If the led blinking is active, stop it
		//
		if(m_IsLedBlinking)
		{
			OnBlinkLed();
		}
		
		m_AdNumber = NewAdNumber;

		//
		// Even if WriteDownAdapterDetails(), we don't need to save the results any more, because we discard them.
		// Therefore, just clear m_NeedToSave and remove the asterisk from the title.
		//
		m_NeedToSave = FALSE;

		if(!FillAdapterDetails(m_AdaptersList[m_AdNumber].Name))
		{
			MessageBox(m_LastErr);
		}
	}
}

BOOL CAirpcapConfDlg::FillAdapterDetails(CString AdName)
{
	PAirpcapHandle Ad;
	CHAR Ebuf[AIRPCAP_ERRBUF_SIZE];
	CString s, s1;
	UINT i, j;
	UINT Channel;
	AirpcapLinkType LinkLayer;
	BOOL IsFcsPresent;
	AirpcapValidationType CrcValidationOn;
	AirpcapDecryptionState WepOperation;
	PAirpcapKeysCollection KeysCollection = NULL;
	UINT KeysCollectionSize;

	//
	// Clear the error string
	//
	m_LastErr = "";

	//
	// Clean the list of encryption keys
	//
	m_KeysArray.RemoveAll();

	//
	// Open the adapter
	//
	Ad = AirpcapOpen(AdName.GetBuffer(1), Ebuf);
	if(!Ad)
	{
		m_LastErr = "error opening the adapter: ";
		m_LastErr += Ebuf;

		return FALSE;
	}

	//
	// Find the channel and set the channel combobox
	//
	m_ComboChannel.ResetContent();
	for(i = 0; i < MAX_WIRELESS_CHANNELS; i++)
	{
		s.Format("%u", i + 1);
		m_ComboChannel.InsertString(-1, s);
	}

	if(!AirpcapGetDeviceChannel(Ad, &Channel))
	{
		m_LastErr = "error getting the channel: ";
		m_LastErr += AirpcapGetLastError(Ad);

		AirpcapClose(Ad);

		return FALSE;
	}

	s.Format("%u", Channel);
	m_ComboChannel.SelectString(-1, s);

	//
	// Find the link layer
	//
	m_ComboLinkLayer.ResetContent();
	m_ComboLinkLayer.InsertString(-1, "802.11 Only");
	m_ComboLinkLayer.InsertString(-1, "802.11 + Radio");

	if(!AirpcapGetLinkType(Ad, &LinkLayer))
	{
		m_LastErr = "error getting the link layer: ";
		m_LastErr += AirpcapGetLastError(Ad);

		AirpcapClose(Ad);

		return FALSE;
	}

	switch(LinkLayer)
	{
	case AIRPCAP_LT_802_11:

		m_ComboLinkLayer.SetCurSel(0);

		break;

	case AIRPCAP_LT_802_11_PLUS_RADIO:

		m_ComboLinkLayer.SetCurSel(1);

		break;
	}

	//
	// Find if FCS is present
	//
	if(!AirpcapGetFcsPresence(Ad, &IsFcsPresent))
	{
		m_LastErr = "error checking the fcs presence: ";
		m_LastErr += AirpcapGetLastError(Ad);

		AirpcapClose(Ad);

		return FALSE;
	}

	m_CheckFcs.SetCheck(IsFcsPresent);

	//
	// Find FCS validation type
	//
	m_ComboFramesToAccpet.ResetContent();
	m_ComboFramesToAccpet.InsertString(-1, "All Frames");
	m_ComboFramesToAccpet.InsertString(-1, "Valid Frames");
	m_ComboFramesToAccpet.InsertString(-1, "Invalid Frames");

	if(!AirpcapGetFcsValidation(Ad, &CrcValidationOn))
	{
		m_LastErr = "error checking the fcs validation: ";
		m_LastErr += AirpcapGetLastError(Ad);

		AirpcapClose(Ad);

		return FALSE;
	}

	switch(CrcValidationOn)
	{
	case AIRPCAP_VT_ACCEPT_EVERYTHING:
		m_ComboFramesToAccpet.SetCurSel(0);
		break;

	case AIRPCAP_VT_ACCEPT_CORRECT_FRAMES:
		m_ComboFramesToAccpet.SetCurSel(1);
		break;

	case AIRPCAP_VT_ACCEPT_CORRUPT_FRAMES:
		m_ComboFramesToAccpet.SetCurSel(2);
		break;

	default:
		m_ComboFramesToAccpet.SetCurSel(0);
		break;
	}

	//
	// Get the WEP decryption state
	//
	if(!AirpcapGetDecryptionState(Ad, &WepOperation))
	{
		m_LastErr = "error checking the fcs presence: ";
		m_LastErr += AirpcapGetLastError(Ad);

		AirpcapClose(Ad);

		return FALSE;
	}

	if(WepOperation == AIRPCAP_DECRYPTION_ON)
	{
		m_CheckWepEnabled.SetCheck(TRUE);
	}
	else
	{
		m_CheckWepEnabled.SetCheck(FALSE);
	}

	//
	// Get and display the encryption keys
	//

	// Delete all of the columns in the listview.
	m_ListKeys.DeleteAllItems();

	for(i = 0; i < 2; i++)
	{
		m_ListKeys.DeleteColumn(0);
	}

	// Init the listview
	CRect r;
	m_ListKeys.GetClientRect(&r);

	m_ListKeys.InsertColumn(0, "Keys", LVCFMT_LEFT, r.Width());

	// get the keys
	KeysCollectionSize = 0;
	if(!AirpcapGetDeviceKeys(Ad, NULL, &KeysCollectionSize))
	{
		if(KeysCollectionSize == 0)
		{
			m_LastErr = "error retrieving the encryption keys buffer";

			AirpcapClose(Ad);
	
			return FALSE;
		}

		// We use malloc so it's easier to reuse the code in C programs
		KeysCollection = (PAirpcapKeysCollection)malloc(KeysCollectionSize);
		if(!KeysCollection)
		{
			m_LastErr = "error allocatin encryption keys buffer";

			AirpcapClose(Ad);

			return FALSE;
		}

		AirpcapGetDeviceKeys(Ad, KeysCollection, &KeysCollectionSize);

		for(i = 0; i < KeysCollection->nKeys; i++)
		{
			//
			// Only encryption is supported for the moment
			//
			if(KeysCollection->Keys[i].KeyType == AIRPCAP_KEYTYPE_WEP)
			{
				s = "";
				for(j = 0; j < KeysCollection->Keys[i].KeyLen != 0; j++)
				{
					s1.Format("%.2x", KeysCollection->Keys[i].KeyData[j]);
					s += s1;
				}
				
				m_KeysArray.Add(s);
			}
		}

		PopulateKeysListControl();
	}

	//
	// Success! Release storage
	//
	if(KeysCollection)
	{
		free(KeysCollection);
	}

	AirpcapClose(Ad);

	return TRUE;
}

BOOL CAirpcapConfDlg::WriteDownAdapterDetails(CString AdName)
{
	PAirpcapHandle Ad;
	CHAR Ebuf[AIRPCAP_ERRBUF_SIZE];
	CString s, s1;
	INT i, j;
	PAirpcapKeysCollection KeysCollection;
	ULONG KeysCollectionSize;
	UCHAR KeyByte;

	//
	// Clear the error string
	//
	m_LastErr = "";

	//
	// Open the adapter
	//
	Ad = AirpcapOpen(AdName.GetBuffer(1), Ebuf);
	if(!Ad)
	{
		m_LastErr = "error opening the adapter ";
		m_LastErr = AdName.GetBuffer(1);
		m_LastErr += ": ";
		m_LastErr += Ebuf;
		return FALSE;
	}

	//
	// Try to save current config, to make sure we can write to the registry
	//
	if(!AirpcapStoreCurConfigAsAdapterDefault(Ad))
	{
		m_LastErr += AirpcapGetLastError(Ad);
		m_LastErr += "\nRemember that in order to store the configuration in the registry you have to:\n\n";
		m_LastErr += " - Close all the airpcap-based applications.\n";
		m_LastErr += " - Be sure to have administrative privileges.";

		AirpcapClose(Ad);
		return FALSE;
	}

	//
	// Save the buffer size
	//
	if(!AirpcapSetKernelBuffer(Ad, 1024 * 1024))
	{
		m_LastErr = "error setting the kernel buffer: ";
		m_LastErr += AirpcapGetLastError(Ad);
		AirpcapClose(Ad);
		return FALSE;
	}

	//
	// Save channel
	//
	INT ChannelToSave = m_ComboChannel.GetCurSel() + 1;

	if(!AirpcapSetDeviceChannel(Ad, ChannelToSave))
	{
		m_LastErr = "error setting the channel: ";
		m_LastErr += AirpcapGetLastError(Ad);
		AirpcapClose(Ad);
		return NULL;
	}

	//
	// Save the link layer
	//
	INT LinkLayerToSave = m_ComboLinkLayer.GetCurSel();

	if(LinkLayerToSave == 0)
	{
		if(!AirpcapSetLinkType(Ad, AIRPCAP_LT_802_11))
		{
			m_LastErr = "error setting the link layer: ";
			m_LastErr += AirpcapGetLastError(Ad);
			AirpcapClose(Ad);
			return NULL;
		}
	}
	else
	{
		if(!AirpcapSetLinkType(Ad, AIRPCAP_LT_802_11_PLUS_RADIO))
		{
			m_LastErr = "error setting the link layer: ";
			m_LastErr += AirpcapGetLastError(Ad);
			AirpcapClose(Ad);
			return NULL;
		}
	}

	//
	// Save if FCS is present
	//
	if(m_CheckFcs.GetCheck())
	{
		if(!AirpcapSetFcsPresence(Ad, TRUE))
		{
			m_LastErr = "error setting the FCS presence: ";
			m_LastErr += AirpcapGetLastError(Ad);
			AirpcapClose(Ad);
			return FALSE;
		}
	}
	else
	{
		if(!AirpcapSetFcsPresence(Ad, FALSE))
		{
			m_LastErr = "error setting the FCS presence: ";
			m_LastErr += AirpcapGetLastError(Ad);
			AirpcapClose(Ad);
			return FALSE;
		}
	}


	//
	// Save if FCS check is enabled
	//
	switch(m_ComboFramesToAccpet.GetCurSel())
	{
	case 0:
		if(!AirpcapSetFcsValidation(Ad, AIRPCAP_VT_ACCEPT_EVERYTHING))
		{
			m_LastErr = "error setting the CRC validation: ";
			m_LastErr += AirpcapGetLastError(Ad);
			AirpcapClose(Ad);
			return FALSE;
		}
		
		break;

	case 1:
		if(!AirpcapSetFcsValidation(Ad, AIRPCAP_VT_ACCEPT_CORRECT_FRAMES))
		{
			m_LastErr = "error setting the CRC validation: ";
			m_LastErr += AirpcapGetLastError(Ad);
			AirpcapClose(Ad);
			return FALSE;
		}
		
		break;

	case 2:
		if(!AirpcapSetFcsValidation(Ad, AIRPCAP_VT_ACCEPT_CORRUPT_FRAMES))
		{
			m_LastErr = "error setting the CRC validation: ";
			m_LastErr += AirpcapGetLastError(Ad);
			AirpcapClose(Ad);
			return FALSE;
		}
		
		break;
	}

	//
	// Save the WEP decryption state
	//
	if(m_CheckWepEnabled.GetCheck())
	{
		if(!AirpcapSetDecryptionState(Ad, AIRPCAP_DECRYPTION_ON))
		{
			m_LastErr = "error setting decryption operation: ";
			m_LastErr += AirpcapGetLastError(Ad);
			
			AirpcapClose(Ad);
			return FALSE;
		}
	}
	else
	{
		if(!AirpcapSetDecryptionState(Ad, AIRPCAP_DECRYPTION_OFF))
		{
			m_LastErr = "error setting decryption operation: ";
			m_LastErr += AirpcapGetLastError(Ad);
			
			AirpcapClose(Ad);
			return FALSE;
		}
	}

	//
	// Save the encryption keys, if we have any of them
	//
	KeysCollectionSize = 0;
	
	//
	// Calculate the size of the keys collection
	//
	KeysCollectionSize = sizeof(AirpcapKeysCollection) + m_KeysArray.GetSize() * sizeof(AirpcapKey);
	
	//
	// Allocate the collection
	// We use malloc so it's easier to reuse the code in C programs
	//
	KeysCollection = (PAirpcapKeysCollection)malloc(KeysCollectionSize);
	if(!KeysCollection)
	{
		m_LastErr = "Memory allocation failure", "Error Applying the changes";
		AirpcapClose(Ad);
		return FALSE;
	}
	
	//
	// Populate the key collection
	//
	KeysCollection->nKeys = m_KeysArray.GetSize();
	
	for(i = 0; i < m_KeysArray.GetSize(); i++)
	{
		KeysCollection->Keys[i].KeyType = AIRPCAP_KEYTYPE_WEP;
		KeysCollection->Keys[i].KeyLen = m_KeysArray[i].GetLength() / 2;
		memset(&KeysCollection->Keys[i].KeyData, 0, sizeof(KeysCollection->Keys[i].KeyData));
		
		for(j = 0 ; j < m_KeysArray[i].GetLength(); j += 2)
		{
			s = m_KeysArray[i].Mid(j, 2);
			KeyByte = (UCHAR)strtol(s, NULL, 16);
			KeysCollection->Keys[i].KeyData[j / 2] = KeyByte;
		}
	}
	
	if(!AirpcapSetDeviceKeys(Ad, KeysCollection))
	{
		m_LastErr = "error storing the encryption keys: ";
		m_LastErr += AirpcapGetLastError(Ad);
		AirpcapClose(Ad);
		return FALSE;
	}
	
	//
	// Tell the driver to store everything in the registry
	//
	if(!AirpcapStoreCurConfigAsAdapterDefault(Ad))
	{
		m_LastErr += AirpcapGetLastError(Ad);
		m_LastErr += "\nRemember that in order to store the configuration in the registry you have to:\n\n";
		m_LastErr += " - Close all the airpcap-based applications.\n";
		m_LastErr += " - Be sure to have administrative privileges.";

		AirpcapClose(Ad);
		return FALSE;
	}
	
	//
	// Release storage
	//
	if(KeysCollection)
	{
		free(KeysCollection);
	}

	AirpcapClose(Ad);

	//
	// Success! Remove the asterisk from the window title
	//
	SetWindowText(TITLE_STRING);

	return TRUE;
}

void CAirpcapConfDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CAirpcapConfDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CAirpcapConfDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CAirpcapConfDlg::OnClose() 
{	
	CDialog::OnClose();
}

void CAirpcapConfDlg::OnApply() 
{
	INT AdNumber = m_InterfacesCombo.GetCurSel();
	CString s;
	
	//
	// If the LED is blinking, stop it
	//
	if(m_IsLedBlinking)
	{
		OnBlinkLed();
	}

	//
	// Save the configuration
	//
	if(AdNumber != -1)
	{
		if(WriteDownAdapterDetails(m_AdaptersList[AdNumber].Name))
		{
			m_NeedToSave = FALSE;
		}
		else
		{
			s = "Unable to save the properties for the selected adapter:\n";
			s += m_LastErr;
			MessageBox(s, "Save error", MB_OK | MB_ICONERROR);
		}
	}
	else
	{
		MessageBox("No Adapter Selected");
	}
}

BOOL CAirpcapConfDlg::PopulateKeysListControl()
{
	INT i;

	//
	// clean the listview.
	//
	m_ListKeys.DeleteAllItems();

	//
	// Add the keys
	//
	for(i = 0; i < m_KeysArray.GetSize(); i++)
	{
		m_ListKeys.InsertItem(i, m_KeysArray[i]);
	}

	return TRUE;
}

void CAirpcapConfDlg::OnAddKey() 
{
	CDlgWepKey Dlg;
	
	Dlg.m_WindowTitle = "Add a Wep Key";
	
	if(m_KeysArray.GetSize() == MAX_ENCRYPTION_KEYS)
	{
		MessageBox("Reached the Wep Keys Limit for this Interface");
		return;
	}
	
	if(Dlg.DoModal() == IDOK)
	{
		m_KeysArray.Add(Dlg.m_Key);
		NeedToSave();
	}

	PopulateKeysListControl();
}

void CAirpcapConfDlg::OnRemoveKey() 
{
	INT SelectedItem = m_ListKeys.GetNextItem(-1, LVNI_SELECTED);

	if(SelectedItem != -1)
	{
		m_KeysArray.RemoveAt(SelectedItem);
		PopulateKeysListControl();
		NeedToSave();
	}
}

void CAirpcapConfDlg::OnEditKey() 
{
	INT SelectedItem = m_ListKeys.GetNextItem(-1, LVNI_SELECTED);

	if(SelectedItem != -1)
	{
		CDlgWepKey Dlg;
		
		Dlg.m_WindowTitle = "Edit Wep Key";

		Dlg.m_Key = m_KeysArray[SelectedItem];
		
		if(m_KeysArray.GetSize() == MAX_ENCRYPTION_KEYS)
		{
			MessageBox("Reached the Encryption Keys Limit for this Interface");
			return;
		}
		
		if(Dlg.DoModal() == IDOK)
		{
			m_KeysArray[SelectedItem] = Dlg.m_Key;
		}
		
		PopulateKeysListControl();

		NeedToSave();
	}
}

void CAirpcapConfDlg::OnMoveKeyUp() 
{
	CString s;
	INT SelectedItem = m_ListKeys.GetNextItem(-1, LVNI_SELECTED);

	if(SelectedItem > 0)
	{
		s = m_KeysArray[SelectedItem - 1];
		m_KeysArray[SelectedItem - 1] = m_KeysArray[SelectedItem];
		m_KeysArray[SelectedItem] = s;

		PopulateKeysListControl();

		m_ListKeys.SetItemState(SelectedItem - 1, TVIS_SELECTED,  TVIS_SELECTED);

		NeedToSave();
	}	
}

void CAirpcapConfDlg::OnMoveKeyDown() 
{
	CString s;
	INT SelectedItem = m_ListKeys.GetNextItem(-1, LVNI_SELECTED);

	if(SelectedItem != -1 && SelectedItem < m_KeysArray.GetSize() - 1)
	{
		s = m_KeysArray[SelectedItem + 1];
		m_KeysArray[SelectedItem + 1] = m_KeysArray[SelectedItem];
		m_KeysArray[SelectedItem] = s;

		PopulateKeysListControl();

		m_ListKeys.SetItemState(SelectedItem + 1, TVIS_SELECTED,  TVIS_SELECTED);

		NeedToSave();
	}		
}

void CAirpcapConfDlg::OnBlinkLed() 
{
	INT AdNumber = m_InterfacesCombo.GetCurSel();

	if(AdNumber == -1)
	{
		MessageBox("No Adapter Selected");
		return;
	}

	//
	// check the state
	//
	if(m_IsLedBlinking)
	{
		//
		// We're blinking now
		//
		m_ButtonLedBlinking.SetWindowText("Blink Led");
		
		//
		// Order the thread to die
		//
		m_IsLedBlinking = FALSE;

		//
		// Wait for the thread to die
		//
		WaitForSingleObject(m_BlinkThread->m_hThread, INFINITE);
	}
	else
	{
		//
		// We're not blinking now
		//
		m_ButtonLedBlinking.SetWindowText("Stop Blinking");
		m_IsLedBlinking = TRUE;

		//
		// Create the thread that will blink the led
		//
		m_BlinkThread = AfxBeginThread(
		CAirpcapConfDlg::BlinkFunctionStatic,
		this,
		THREAD_PRIORITY_NORMAL,
		0,
		0,
		NULL);

		if (this->m_BlinkThread != NULL)
		{
			return;
		}
	}
}

UINT CAirpcapConfDlg::BlinkFunctionStatic(LPVOID pParam)
{
	PAirpcapHandle Ad;
	CHAR Ebuf[AIRPCAP_ERRBUF_SIZE];

	CAirpcapConfDlg* This = (CAirpcapConfDlg*)pParam;
	INT AdNumber = This->m_InterfacesCombo.GetCurSel();

	//
	// Open the adapter
	//
	Ad = AirpcapOpen(This->m_AdaptersList[AdNumber].Name.GetBuffer(1), Ebuf);
	if(!Ad)
	{
		return 0;
	}

	//
	// Loop blinking until we are odered to die
	//
	while(This->m_IsLedBlinking)
	{
		AirpcapTurnLedOff(Ad, 0);
		Sleep(BLINK_DELAY_MS);
		AirpcapTurnLedOn(Ad, 0);
		Sleep(BLINK_DELAY_MS);
	}

	//
	// Cleanup and au revoire
	//
	AirpcapClose(Ad);	

	return 1;
}

void CAirpcapConfDlg::OnOk() 
{
	INT AdNumber = m_InterfacesCombo.GetCurSel();
	
	//
	// If the LED is blinking, stop it
	//
	if(m_IsLedBlinking)
	{
		OnBlinkLed();
	}

	//
	// Save the configuration
	//
	if(AdNumber != -1)
	{
		if(!WriteDownAdapterDetails(m_AdaptersList[AdNumber].Name))
		{
			MessageBox("Error while storing the adapter configuration in the registry.\nMake sure you have closed all the airpcap-based applications.");
		}	
	}

	CDialog::OnOK();
}

void CAirpcapConfDlg::OnHelp() 
{
	TCHAR AppDir[MAX_PATH];
	TCHAR drive[MAX_PATH];
	TCHAR path[MAX_PATH];
	CString ManualDir;
	
	GetModuleFileName(NULL, AppDir, MAX_PATH);
	_tsplitpath(AppDir, drive, path, NULL, NULL);

	ManualDir = drive;
	ManualDir += path;

	if((INT)ShellExecute(NULL,
		"Open",
		"airpcap_user_guide.pdf",
		"",
		ManualDir,
		SW_RESTORE) <= 32)
	{
		MessageBox("Error while displaying the help file.");
	}
}

void CAirpcapConfDlg::OnCancel() 
{
	//
	// If the LED is blinking, stop it
	//
	if(m_IsLedBlinking)
	{
		OnBlinkLed();
	}
	
	CDialog::OnCancel();
}

void CAirpcapConfDlg::NeedToSave()
{
	CString s = TITLE_STRING;

	SetWindowText(s + " *");
	m_NeedToSave = TRUE;
}

void CAirpcapConfDlg::OnChangeChannel() 
{
	NeedToSave();
}

void CAirpcapConfDlg::OnChangeLinkLayer() 
{
	NeedToSave();
}

void CAirpcapConfDlg::OnSelchangeComboFramestoaccept() 
{
	NeedToSave();	
}

void CAirpcapConfDlg::OnChangeCrcInclusion() 
{
	NeedToSave();
}

void CAirpcapConfDlg::OnChangeCrcCalculation() 
{
	NeedToSave();
}

void CAirpcapConfDlg::OnChangeWepOperation() 
{	
	NeedToSave();
}

void CAirpcapConfDlg::OnReset() 
{
	CString s, s1;
	UINT i;

	//
	// If the LED is blinking, stop it
	//
	if(m_IsLedBlinking)
	{
		OnBlinkLed();
	}

	//
	// Clear the error string
	//
	m_LastErr = "";

	//
	// Clean the list of encryption keys
	//
	m_KeysArray.RemoveAll();

	//
	// Set channel 6
	//
	m_ComboChannel.ResetContent();
	for(i = 0; i < MAX_WIRELESS_CHANNELS; i++)
	{
		s.Format("%u", i + 1);
		m_ComboChannel.InsertString(-1, s);
	}

	m_ComboChannel.SetCurSel(5);

	//
	// Set radiotap link layer
	//
	m_ComboLinkLayer.ResetContent();
	m_ComboLinkLayer.InsertString(-1, "802.11 Only");
	m_ComboLinkLayer.InsertString(-1, "802.11 + Radio");

	m_ComboLinkLayer.SetCurSel(1);

	//
	// FCS is present
	//
	m_CheckFcs.SetCheck(TRUE);

	//
	// No FCS validation
	//
	m_ComboFramesToAccpet.ResetContent();
	m_ComboFramesToAccpet.InsertString(-1, "All Packets");
	m_ComboFramesToAccpet.InsertString(-1, "Valid Packets");
	m_ComboFramesToAccpet.InsertString(-1, "Wrong CRC Packets");

	m_ComboFramesToAccpet.SetCurSel(0);

	//
	// Delete all of the columns in the encryption keys listview
	//
	m_ListKeys.DeleteAllItems();

	//
	// The configuration has changed, mark that it needs to be saved
	//
	NeedToSave();
}

void CAirpcapConfDlg::OnDropdownComboInterfaces() 
{
//	FillAdapterList();
}

void CAboutDlg::OnOK() 
{
	// TODO: Add extra validation here
	
	CDialog::OnOK();
}
