/*
 * Copyright (c) 2006 CACE Technologies, Davis (California)
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 * notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 * notice, this list of conditions and the following disclaimer in the
 * documentation and/or other materials provided with the distribution.
 * 3. Neither the name CACE Technologies nor the names of its contributors 
 * may be used to endorse or promote products derived from this software 
 * without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

#include "stdafx.h"
#include "AirpcapConf.h"
#include "DlgWepKey.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlgWepKey dialog


CDlgWepKey::CDlgWepKey(CWnd* pParent /*=NULL*/)
	: CDialog(CDlgWepKey::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDlgWepKey)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT

	m_Key = "";
}


void CDlgWepKey::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlgWepKey)
	DDX_Control(pDX, IDC_EDIT1, m_EditKey);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDlgWepKey, CDialog)
	//{{AFX_MSG_MAP(CDlgWepKey)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlgWepKey message handlers

BOOL CDlgWepKey::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	SetWindowText(m_WindowTitle);
	m_EditKey.SetWindowText(m_Key);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDlgWepKey::OnOK() 
{
	m_EditKey.GetWindowText(m_Key);

	INT i;
	int StringCheck;
	CString s;

	m_Key.TrimLeft();
	m_Key.TrimRight();

	if((m_Key.GetLength() / 2 * 2) != m_Key.GetLength())
	{
		MessageBox("A Wep key must is an arbitrary length hexadecimal number.\nThe valid characters are: 0123456789ABCDEF.\nThe number of characters must be even.", 
			"Not a Valid Wep Key");
		return;
	}		

	for(i = 0; i < m_Key.GetLength(); i++)
	{
		s = m_Key.GetAt(i);
		StringCheck = s.FindOneOf("0123456789abcdefABCDEF");
		if(StringCheck == -1)
		{
			MessageBox("A Wep key must is an arbitrary length hexadecimal number.\nThe valid characters are: 0123456789ABCDEF.\nThe number of characters must be even.", 
				"Not a Valid Wep Key");
			return;
		}		
	}

	CDialog::OnOK();
}
