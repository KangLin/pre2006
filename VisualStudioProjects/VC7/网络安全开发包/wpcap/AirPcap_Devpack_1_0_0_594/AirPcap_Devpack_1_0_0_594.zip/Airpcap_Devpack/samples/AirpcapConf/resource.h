//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by AirpcapConf.rc
//
#define IDOK2                           3
#define IDOK3                           4
#define IDOK4                           5
#define IDOK5                           6
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_AIRPCAPCONF_DIALOG          102
#define IDR_MAINFRAME                   128
#define IDB_BITMAP1                     131
#define IDD_DIALOG1                     132
#define IDI_ICON1                       136
#define IDB_CACE                        142
#define IDC_COMBO1                      1001
#define IDC_COMBO_INTERFACES            1001
#define IDC_BUTTON1                     1002
#define IDC_BUTTON_LED                  1002
#define IDC_CHECK1                      1003
#define IDC_CHECK_FCS                   1003
#define IDC_COMBO2                      1004
#define IDC_COMBO_CHANNEL               1004
#define IDC_COMBO3                      1005
#define IDC_COMBO_LINKLAYER             1005
#define IDC_CHECK2                      1006
#define IDC_CHECK_FCSVALIDATION         1006
#define IDC_CHECK_WEP                   1006
#define IDC_COMBO_FRAMESTOACCEPT        1007
#define IDC_EDIT_BUFSIZE                1010
#define IDC_LIST1                       1011
#define IDC_LIST_WEPKEYS                1011
#define IDC_BUTTON3                     1014
#define IDC_BUTTON4                     1015
#define IDC_BUTTON5                     1016
#define IDC_BUTTON6                     1017
#define IDC_BUTTON7                     1018
#define ID_BUTTON_APPLY                 1019
#define IDC_EDIT1                       1020
#define IDC_PROGRESS1                   1021

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        144
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1022
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
