/*
 * Copyright (c) 2006 CACE Technologies, Davis (California)
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 * LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 * THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 * AirPcap libray implentation.
 *
 */

#include <windows.h>
#include <winioctl.h>
#include <stdio.h>
#include <stdlib.h>

#include "ioctls.h"
#include "airpcap.h"
#include "..\version\version.h"

///////////////////////////////////////////////////////////////////
// Private definitions
///////////////////////////////////////////////////////////////////

#define MAX_AIRPCAP_CARDS		100
#define DEVICESTRING			"\\\\.\\Global\\airpcap%.2d"
#define DEVICESTRING_NO_PREFIX	"\\\\.\\airpcap%.2d"

struct _AirpcapHandle
{
	HANDLE OsHandle;			
	HANDLE ReadEvent;
	UINT Flags;			// Currently unused?
	CHAR Ebuf[AIRPCAP_ERRBUF_SIZE];
};

///////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////

BOOL APIENTRY DllMain(HANDLE hModule, DWORD  ul_reason_for_call, LPVOID lpReserved)
{
    switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		case DLL_PROCESS_DETACH:
			break;
    }
    return TRUE;
}

///////////////////////////////////////////////////////////////////

void AirpcapGetVersion(PUINT VersionMajor, PUINT VersionMinor, PUINT VersionRev, PUINT VersionBuild)
{
	*VersionMajor = AIRPCAP_PROJ_MAJOR;
	*VersionMinor = AIRPCAP_PROJ_MINOR;
	*VersionRev = AIRPCAP_PROJ_REV;
	*VersionBuild = AIRPCAP_PROJ_BUILD;
}

///////////////////////////////////////////////////////////////////

void AirpcapAppendLastError(char *ebuf)
{
   char lasterr[256], tmpbuf[AIRPCAP_ERRBUF_SIZE];

   DWORD   err = GetLastError();
   
   FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM, 
      NULL, 
      err,
      0, 
      lasterr, 
      sizeof(lasterr), 
      NULL);

   _snprintf(tmpbuf, AIRPCAP_ERRBUF_SIZE, "%s - %s", ebuf, lasterr);
   memcpy(ebuf, tmpbuf, AIRPCAP_ERRBUF_SIZE);
}

///////////////////////////////////////////////////////////////////

PCHAR AirpcapGetLastError(PAirpcapHandle AdapterHandle)
{
	return AdapterHandle->Ebuf;
}

///////////////////////////////////////////////////////////////////

int AirpcapInsertDeviceInList(AirpcapDeviceDescription **DescHead, char *Name, char *Desc)
{
   AirpcapDeviceDescription *t;
   
   
   if((t = (AirpcapDeviceDescription*)malloc(sizeof(AirpcapDeviceDescription))) != NULL)
   {
      t->Name = strdup(Name);
      if(!t->Name)
      {
         free(t);
         return -1;
      }

      t->Description = strdup(Desc);
      
      t->next = *DescHead;
      *DescHead = t;
      return 1;
   }
   else
   {
      return -1;
   }
   
   return 0;
}

///////////////////////////////////////////////////////////////////

BOOL AirpcapGetDeviceList(PAirpcapDeviceDescription *PPAllDevs, PCHAR Ebuf)
{
	AirpcapDeviceDescription *alldevs = NULL;
	
	CHAR		DeviceName[256];   // to be generous
	UINT		NBoards = 0;
	CHAR		Desc[256];
	UINT		i;
	HANDLE		AdHandle;
	
	for(i = 0; i < MAX_AIRPCAP_CARDS; i++)
	{
		//
		// Note: we are sure that the list of dag device names is without gaps, so 
		// scanning until the open fails is safe and grants to find all the devices
		//
		_snprintf(DeviceName, sizeof(DeviceName), DEVICESTRING, i);
		AdHandle = CreateFile(
			DeviceName,         
			GENERIC_READ,      
			0,               
			NULL,            
			OPEN_EXISTING,      
			0,               
			0);
		
		if(AdHandle == INVALID_HANDLE_VALUE)
		{
			// unable to open this device, skip to the next one
			continue;
		}
		
		//
		// Done with the handle, close it
		//
		CloseHandle(AdHandle);

		//
		// Create the name
		//
		_snprintf(DeviceName, sizeof(DeviceName), DEVICESTRING_NO_PREFIX, i);

		//
		// Create the description
		//
		_snprintf(Desc, 
			sizeof(Desc), 
			"AirPcap USB wireless capture adapter nr. %.2u", 
			i);

		AirpcapInsertDeviceInList(&alldevs, DeviceName, Desc);
		NBoards++;
		
	}
	
	*PPAllDevs = alldevs;
	
	return TRUE;
}

///////////////////////////////////////////////////////////////////

VOID AirpcapFreeDeviceList(AirpcapDeviceDescription *PAllDevs)
{
	AirpcapDeviceDescription *PCurDevs, *PNextDevs;
	
	for(PCurDevs = PAllDevs; PCurDevs != NULL; PCurDevs = PNextDevs)
	{
		PNextDevs = PCurDevs->next;
		
		if(PCurDevs->Description)
		{
			free(PCurDevs->Description);
		}

		free(PCurDevs->Name);
		free(PCurDevs);
	}
}

///////////////////////////////////////////////////////////////////

PAirpcapHandle AirpcapOpen(PCHAR DeviceName, PCHAR Ebuf)
{
	int retcode = 0;
	DWORD BytesReturned;
	PAirpcapHandle AdapterHandle;
	HANDLE hEvent;
	CHAR CompleteName[256];
	UINT DeviceNumber;

	//
	// Add the global prefix to make it possible to open the device from terminal services
	//
	if(sscanf(DeviceName, AIRPCAP_DEVICE_NUMBER_EXTRACT_STRING, &DeviceNumber) != 1)
	{
		_snprintf(Ebuf, AIRPCAP_ERRBUF_SIZE, "Unable to open device - wrong device name\n");
		return NULL;
	}
	else
	{
		_snprintf(CompleteName, sizeof(CompleteName), DEVICESTRING, DeviceNumber);
	}

	//
	// Allocate the handlde
	//
	AdapterHandle = (PAirpcapHandle)malloc(sizeof(AirpcapHandle));
	if(!AdapterHandle)
	{
		_snprintf(Ebuf, AIRPCAP_ERRBUF_SIZE, "Memory allocation failure\n");
		return NULL;
	}

	//
	// Open the device
	//
	AdapterHandle->OsHandle = CreateFile(CompleteName, GENERIC_READ, 0, NULL, OPEN_EXISTING, 0, NULL);
	if(AdapterHandle->OsHandle == INVALID_HANDLE_VALUE) 
	{
		_snprintf(Ebuf, AIRPCAP_ERRBUF_SIZE, "Unable to open device - error %d\n", GetLastError());
		free(AdapterHandle);
		return NULL;
	}

	//
	// Open the event for this device
	//
	hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);

	if(hEvent == NULL)
	{
		_snprintf(Ebuf, AIRPCAP_ERRBUF_SIZE, "Unable to set the read event: %d\n", GetLastError());
		CloseHandle(AdapterHandle->OsHandle);
		free(AdapterHandle);
		return FALSE;
	}

	if(DeviceIoControl(AdapterHandle->OsHandle,
			IOCTL_SETSHAREDEVENT,
			&hEvent,
			sizeof(hEvent),
			NULL,
			0,
			&BytesReturned,
			NULL)==FALSE) 
	{
		_snprintf(Ebuf, AIRPCAP_ERRBUF_SIZE, "Unable to set the read event: %d\n", GetLastError());
		CloseHandle(hEvent);
		CloseHandle(AdapterHandle->OsHandle);
		free(AdapterHandle);
		return FALSE;
	}

	AdapterHandle->ReadEvent = hEvent;

	return AdapterHandle;
}

///////////////////////////////////////////////////////////////////

VOID AirpcapClose(PAirpcapHandle AdapterHandle)
{
	CloseHandle(AdapterHandle->ReadEvent);
	CloseHandle(AdapterHandle->OsHandle);

	free(AdapterHandle);
}

///////////////////////////////////////////////////////////////////

BOOL AirpcapSetDeviceChannel(PAirpcapHandle AdapterHandle, UINT Channel)
{
	DWORD BytesReturned;

	if(DeviceIoControl(AdapterHandle->OsHandle, IOCTL_SETCHANNEL, &Channel, sizeof(Channel), 
		NULL, 0, 
		&BytesReturned, NULL) == FALSE) 
	{
		_snprintf(AdapterHandle->Ebuf, AIRPCAP_ERRBUF_SIZE, "IOCTL failed: %d\n", GetLastError());
		return FALSE;
	}

	return TRUE;
}

///////////////////////////////////////////////////////////////////

BOOL AirpcapGetDeviceChannel(PAirpcapHandle AdapterHandle, UINT* PChannel)
{
	DWORD BytesReturned;
	INT tChannel;

	if(DeviceIoControl(AdapterHandle->OsHandle, IOCTL_GETCHANNEL, NULL, 0, 
		&tChannel, sizeof(tChannel),
		&BytesReturned, NULL) == FALSE) 
	{
		_snprintf(AdapterHandle->Ebuf, AIRPCAP_ERRBUF_SIZE, "IOCTL failed: %d\n", GetLastError());
		return FALSE;
	}

	*PChannel = tChannel;
	return TRUE;
}

///////////////////////////////////////////////////////////////////

BOOL AirpcapSetLinkType(PAirpcapHandle AdapterHandle, AirpcapLinkType NewLinkType)
{
	DWORD BytesReturned;
	UINT LinkLayerAsUint = NewLinkType;

	if(DeviceIoControl(AdapterHandle->OsHandle, IOCTL_SETLINKLAYER, &LinkLayerAsUint, sizeof(LinkLayerAsUint), 
		NULL, 0, 
		&BytesReturned, NULL) == FALSE) 
	{
		_snprintf(AdapterHandle->Ebuf, AIRPCAP_ERRBUF_SIZE, "IOCTL failed: %d\n", GetLastError());
		return FALSE;
	}

	return TRUE;
}

///////////////////////////////////////////////////////////////////

BOOL AirpcapGetLinkType(PAirpcapHandle AdapterHandle, AirpcapLinkType* PLinkType)
{
	DWORD BytesReturned;
	UINT LinkLayerUAsInt;

	if(DeviceIoControl(AdapterHandle->OsHandle, IOCTL_GETLINKLAYER, NULL, 0, 
		&LinkLayerUAsInt, sizeof(LinkLayerUAsInt),
		&BytesReturned, NULL) == FALSE) 
	{
		_snprintf(AdapterHandle->Ebuf, AIRPCAP_ERRBUF_SIZE, "IOCTL failed: %d\n", GetLastError());
		*PLinkType = AIRPCAP_LT_UNKNOWN;
		return FALSE;
	}

	*PLinkType = LinkLayerUAsInt;

	return TRUE;
}

///////////////////////////////////////////////////////////////////

BOOL AirpcapSetFcsPresence(PAirpcapHandle AdapterHandle, BOOL CrcIsPresent)
{
	DWORD BytesReturned;
	UINT CrcPresenceAsUint = CrcIsPresent;

	if(DeviceIoControl(AdapterHandle->OsHandle, IOCTL_SETCRCPRESENCE, &CrcPresenceAsUint, sizeof(CrcPresenceAsUint), 
		NULL, 0,
		&BytesReturned, NULL) == FALSE) 
	{
		_snprintf(AdapterHandle->Ebuf, AIRPCAP_ERRBUF_SIZE, "IOCTL failed: %d\n", GetLastError());
		return FALSE;
	}

	return TRUE;
}

///////////////////////////////////////////////////////////////////

BOOL AirpcapGetFcsPresence(PAirpcapHandle AdapterHandle, BOOL* PIsFcsPresent)
{
	DWORD BytesReturned;
	UINT CrcPresenceAsUint;

	if(DeviceIoControl(AdapterHandle->OsHandle, IOCTL_GETCRCPRESENCE, NULL, 0, 
		&CrcPresenceAsUint, sizeof(CrcPresenceAsUint),
		&BytesReturned, NULL) == FALSE) 
	{
		_snprintf(AdapterHandle->Ebuf, AIRPCAP_ERRBUF_SIZE, "IOCTL failed: %d\n", GetLastError());
		return FALSE;
	}

	*PIsFcsPresent = (BOOL)CrcPresenceAsUint;

	return TRUE;
}

///////////////////////////////////////////////////////////////////

BOOL AirpcapSetFcsValidation(PAirpcapHandle AdapterHandle, AirpcapValidationType ValidationType)
{

	DWORD BytesReturned;
	UINT CrcDropAsUint = ValidationType;

	if(DeviceIoControl(AdapterHandle->OsHandle, IOCTL_SETCRCVALIDATION, &CrcDropAsUint, sizeof(CrcDropAsUint), 
		NULL, 0,
		&BytesReturned, NULL) == FALSE) 
	{
		_snprintf(AdapterHandle->Ebuf, AIRPCAP_ERRBUF_SIZE, "IOCTL failed: %d\n", GetLastError());
		return FALSE;
	}

	return TRUE;
}

///////////////////////////////////////////////////////////////////

BOOL AirpcapGetFcsValidation(PAirpcapHandle AdapterHandle, PAirpcapValidationType ValidationType)
{
	DWORD BytesReturned;
	UINT CrcDropAsUint;

	if(DeviceIoControl(AdapterHandle->OsHandle, IOCTL_GETCRCVALIDATION, NULL, 0, 
		&CrcDropAsUint, sizeof(CrcDropAsUint),
		&BytesReturned, NULL) == FALSE) 
	{
		_snprintf(AdapterHandle->Ebuf, AIRPCAP_ERRBUF_SIZE, "IOCTL failed: %d\n", GetLastError());
		return FALSE;
	}

	*ValidationType = (BOOL)CrcDropAsUint;

	return TRUE;
}

///////////////////////////////////////////////////////////////////

BOOL AirpcapSetDeviceKeys(PAirpcapHandle AdapterHandle, PAirpcapKeysCollection KeysCollection)
{
	DWORD BytesReturned;

	if(DeviceIoControl(AdapterHandle->OsHandle, 
		IOCTL_SETKEYS, 
		KeysCollection, 
		sizeof(AirpcapKeysCollection) + KeysCollection->nKeys * sizeof(AirpcapKey), 
		NULL, 
		0,
		&BytesReturned, 
		NULL) == FALSE) 
	{
		_snprintf(AdapterHandle->Ebuf, AIRPCAP_ERRBUF_SIZE, "IOCTL failed: %d\n", GetLastError());
		return FALSE;
	}

	return TRUE;
}

///////////////////////////////////////////////////////////////////

BOOL AirpcapGetDeviceKeys(PAirpcapHandle AdapterHandle, PAirpcapKeysCollection KeysCollection, UINT* PKeysCollectionSize)
{
	DWORD BytesReturned;

	if(DeviceIoControl(AdapterHandle->OsHandle, 
		IOCTL_GETKEYS, 
		NULL, 
		0, 
		KeysCollection, 
		*PKeysCollectionSize,
		&BytesReturned, 
		NULL) == FALSE) 
	{
		_snprintf(AdapterHandle->Ebuf, AIRPCAP_ERRBUF_SIZE, "IOCTL failed: %d\n", GetLastError());
		*PKeysCollectionSize = 0;
		return FALSE;
	}
	
	//
	// Check the size
	//
	if(BytesReturned > *PKeysCollectionSize)
	{
		*PKeysCollectionSize = BytesReturned;
		return FALSE;
	}
	
	*PKeysCollectionSize = BytesReturned;
	return TRUE;
}

///////////////////////////////////////////////////////////////////

BOOL AirpcapSetDecryptionState(PAirpcapHandle AdapterHandle, AirpcapDecryptionState Enable)
{
	DWORD BytesReturned;

	if(DeviceIoControl(AdapterHandle->OsHandle, IOCTL_SETDECRYPTIONSTATUS, &Enable, sizeof(Enable), 
		NULL, 0, 
		&BytesReturned, NULL) == FALSE) 
	{
		_snprintf(AdapterHandle->Ebuf, AIRPCAP_ERRBUF_SIZE, "IOCTL failed: %d\n", GetLastError());
		return FALSE;
	}

	return TRUE;
}

///////////////////////////////////////////////////////////////////

BOOL AirpcapGetDecryptionState(PAirpcapHandle AdapterHandle, PAirpcapDecryptionState PEnable)
{
	DWORD BytesReturned;
	UINT Val;

	if(DeviceIoControl(AdapterHandle->OsHandle, IOCTL_GETDECRYPTIONSTATUS, NULL, 0, 
		&Val, sizeof(Val),
		&BytesReturned, NULL) == FALSE) 
	{
		_snprintf(AdapterHandle->Ebuf, AIRPCAP_ERRBUF_SIZE, "IOCTL failed: %d\n", GetLastError());
		return FALSE;
	}

	*PEnable = Val;

	return TRUE;
}

///////////////////////////////////////////////////////////////////

BOOL AirpcapSetKernelBuffer(PAirpcapHandle AdapterHandle, UINT SizeBytes)
{
	DWORD BytesReturned;

	if(DeviceIoControl(AdapterHandle->OsHandle, IOCTL_SETBSIZE, &SizeBytes, sizeof(SizeBytes), 
		NULL, 0, 
		&BytesReturned, NULL) == FALSE) 
	{
		_snprintf(AdapterHandle->Ebuf, AIRPCAP_ERRBUF_SIZE, "IOCTL failed: %d\n", GetLastError());
		return FALSE;
	}

	return TRUE;
}

///////////////////////////////////////////////////////////////////

BOOL AirpcapGetKernelBufferSize(PAirpcapHandle AdapterHandle, UINT* PSizeBytes)
{
	DWORD BytesReturned;
	UINT Size;

	if(DeviceIoControl(AdapterHandle->OsHandle, IOCTL_GETBSIZE, NULL, 0, 
		&Size, sizeof(Size),
		&BytesReturned, NULL) == FALSE) 
	{
		_snprintf(AdapterHandle->Ebuf, AIRPCAP_ERRBUF_SIZE, "IOCTL failed: %d\n", GetLastError());
		return FALSE;
	}

	*PSizeBytes = Size;

	return TRUE;
}

///////////////////////////////////////////////////////////////////

BOOL AirpcapSetFilter(PAirpcapHandle AdapterHandle, void *Instructions, UINT Len)
{
	DWORD BytesReturned;
	
	if(DeviceIoControl(AdapterHandle->OsHandle,
		IOCTL_SETFILTER,
		Instructions,
		Len,
		NULL,
		0,
		&BytesReturned,
		NULL) == FALSE)
	{
		_snprintf(AdapterHandle->Ebuf, AIRPCAP_ERRBUF_SIZE, "IOCTL failed: %d\n", GetLastError());
		return FALSE;
	}

	return TRUE;
}

///////////////////////////////////////////////////////////////////

BOOL AirpcapStoreCurConfigAsAdapterDefault(PAirpcapHandle AdapterHandle)
{
	DWORD BytesReturned;

	if(DeviceIoControl(AdapterHandle->OsHandle, IOCTL_STORECONFIG, NULL, 0, 
		NULL, 0, 
		&BytesReturned, NULL) == FALSE) 
	{
		_snprintf(AdapterHandle->Ebuf, AIRPCAP_ERRBUF_SIZE, "IOCTL failed: %d\n", GetLastError());
		return FALSE;
	}

	return TRUE;
}

///////////////////////////////////////////////////////////////////

BOOL AirpcapGetLedsNumber(PAirpcapHandle AdapterHandle, UINT* NumberOfLeds)
{
	*NumberOfLeds = 1;

	return TRUE;
}

///////////////////////////////////////////////////////////////////

BOOL AirpcapTurnLedOn(PAirpcapHandle AdapterHandle, UINT LedNumber)
{
	DWORD BytesReturned;

	if(LedNumber != 0)
	{
		return FALSE;
	}

	if(DeviceIoControl(AdapterHandle->OsHandle, IOCTL_TURNLEDON, NULL, 0, 
		NULL, 0, 
		&BytesReturned, NULL) == FALSE) 
	{
		_snprintf(AdapterHandle->Ebuf, AIRPCAP_ERRBUF_SIZE, "IOCTL failed: %d\n", GetLastError());
		return FALSE;
	}

	return TRUE;
}

///////////////////////////////////////////////////////////////////

BOOL AirpcapTurnLedOff(PAirpcapHandle AdapterHandle, UINT LedNumber)
{
	DWORD BytesReturned;

	if(LedNumber != 0)
	{
		return FALSE;
	}

	if(DeviceIoControl(AdapterHandle->OsHandle, IOCTL_TURNLEDOFF, NULL, 0, 
		NULL, 0, 
		&BytesReturned, NULL) == FALSE)
	{
		_snprintf(AdapterHandle->Ebuf, AIRPCAP_ERRBUF_SIZE, "IOCTL failed: %d\n", GetLastError());
		return FALSE;
	}

	return TRUE;
}

///////////////////////////////////////////////////////////////////

BOOL AirpcapGetMacAddress(PAirpcapHandle AdapterHandle, AirpcapMacAddress* PMacAddress)
{
	CHAR taddr[6];
	DWORD BytesReturned;

	if(DeviceIoControl(AdapterHandle->OsHandle, IOCTL_GETMACADDR, NULL, 0, 
		taddr, sizeof(taddr),
		&BytesReturned, NULL) == FALSE) 
	{
		_snprintf(AdapterHandle->Ebuf, AIRPCAP_ERRBUF_SIZE, "IOCTL failed: %d\n", GetLastError());
		return FALSE;
	}

	memcpy(PMacAddress, taddr, sizeof(taddr));

	return TRUE;
}

///////////////////////////////////////////////////////////////////

BOOL AirpcapSetMinToCopy(PAirpcapHandle AdapterHandle, UINT Bytes)
{
	DWORD BytesReturned;

	if(DeviceIoControl(AdapterHandle->OsHandle, IOCTL_SMINTOCOPY, &Bytes, sizeof(Bytes), 
		NULL, 0, 
		&BytesReturned, NULL) == FALSE) 
	{
		_snprintf(AdapterHandle->Ebuf, AIRPCAP_ERRBUF_SIZE, "IOCTL failed: %d\n", GetLastError());
		return FALSE;
	}

	return TRUE;
}

///////////////////////////////////////////////////////////////////

BOOL AirpcapGetReadEvent(PAirpcapHandle AdapterHandle, HANDLE* PReadEvent)
{
	*PReadEvent = AdapterHandle->ReadEvent;

	if(AdapterHandle->ReadEvent == NULL)
	{
		return FALSE;
	}

	return TRUE;
}

///////////////////////////////////////////////////////////////////

BOOL AirpcapRead(PAirpcapHandle AdapterHandle, PBYTE BufferToFill, UINT BufSize, PUINT ReceievedBytes)
{
	if(!ReadFile(AdapterHandle->OsHandle, BufferToFill, BufSize, (LPDWORD)ReceievedBytes, NULL)) 
	{
		_snprintf(AdapterHandle->Ebuf, AIRPCAP_ERRBUF_SIZE, "Error %d trying to read data\n", GetLastError());
		return FALSE;
	}

	return TRUE;
}

///////////////////////////////////////////////////////////////////

BOOL AirpcapGetStats(PAirpcapHandle AdapterHandle, AirpcapStats *PStats)
{
	DWORD BytesReturned;

	if(DeviceIoControl(AdapterHandle->OsHandle, IOCTL_GETSTATS, 0, 0, 
		PStats, sizeof(AirpcapStats), 
		&BytesReturned, NULL) == FALSE) 
	{
		_snprintf(AdapterHandle->Ebuf, AIRPCAP_ERRBUF_SIZE, "IOCTL failed: %d\n", GetLastError());
		return FALSE;
	}

	return TRUE;
}
