/* A Bison parser, made by GNU Bison 2.1.  */

/* Skeleton parser for Yacc-like parsing with Bison,
   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

/* Written by Richard Stallman by simplifying the original so called
   ``semantic'' parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "2.1"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Using locations.  */
#define YYLSP_NEEDED 0

/* Substitute the variable and function names.  */
#define yyparse pcap_parse
#define yylex   pcap_lex
#define yyerror pcap_error
#define yylval  pcap_lval
#define yychar  pcap_char
#define yydebug pcap_debug
#define yynerrs pcap_nerrs


/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     DST = 258,
     SRC = 259,
     HOST = 260,
     GATEWAY = 261,
     NET = 262,
     NETMASK = 263,
     PORT = 264,
     PORTRANGE = 265,
     LESS = 266,
     GREATER = 267,
     PROTO = 268,
     PROTOCHAIN = 269,
     CBYTE = 270,
     ARP = 271,
     RARP = 272,
     IP = 273,
     SCTP = 274,
     TCP = 275,
     UDP = 276,
     ICMP = 277,
     IGMP = 278,
     IGRP = 279,
     PIM = 280,
     VRRP = 281,
     ATALK = 282,
     AARP = 283,
     DECNET = 284,
     LAT = 285,
     SCA = 286,
     MOPRC = 287,
     MOPDL = 288,
     TK_BROADCAST = 289,
     TK_MULTICAST = 290,
     NUM = 291,
     INBOUND = 292,
     OUTBOUND = 293,
     PF_IFNAME = 294,
     PF_RSET = 295,
     PF_RNR = 296,
     PF_SRNR = 297,
     PF_REASON = 298,
     PF_ACTION = 299,
     LINK = 300,
     GEQ = 301,
     LEQ = 302,
     NEQ = 303,
     ID = 304,
     EID = 305,
     HID = 306,
     HID6 = 307,
     AID = 308,
     LSH = 309,
     RSH = 310,
     LEN = 311,
     IPV6 = 312,
     ICMPV6 = 313,
     AH = 314,
     ESP = 315,
     VLAN = 316,
     MPLS = 317,
     PPPOED = 318,
     PPPOES = 319,
     ISO = 320,
     ESIS = 321,
     CLNP = 322,
     ISIS = 323,
     L1 = 324,
     L2 = 325,
     IIH = 326,
     LSP = 327,
     SNP = 328,
     CSNP = 329,
     PSNP = 330,
     STP = 331,
     IPX = 332,
     NETBEUI = 333,
     LANE = 334,
     LLC = 335,
     METAC = 336,
     BCC = 337,
     SC = 338,
     ILMIC = 339,
     OAMF4EC = 340,
     OAMF4SC = 341,
     OAM = 342,
     OAMF4 = 343,
     CONNECTMSG = 344,
     METACONNECT = 345,
     VPI = 346,
     VCI = 347,
     RADIO = 348,
     FISU = 349,
     LSSU = 350,
     MSU = 351,
     SIO = 352,
     OPC = 353,
     DPC = 354,
     SLS = 355,
     TYPE = 356,
     SUBTYPE = 357,
     AND = 358,
     OR = 359,
     UMINUS = 360
   };
#endif
/* Tokens.  */
#define DST 258
#define SRC 259
#define HOST 260
#define GATEWAY 261
#define NET 262
#define NETMASK 263
#define PORT 264
#define PORTRANGE 265
#define LESS 266
#define GREATER 267
#define PROTO 268
#define PROTOCHAIN 269
#define CBYTE 270
#define ARP 271
#define RARP 272
#define IP 273
#define SCTP 274
#define TCP 275
#define UDP 276
#define ICMP 277
#define IGMP 278
#define IGRP 279
#define PIM 280
#define VRRP 281
#define ATALK 282
#define AARP 283
#define DECNET 284
#define LAT 285
#define SCA 286
#define MOPRC 287
#define MOPDL 288
#define TK_BROADCAST 289
#define TK_MULTICAST 290
#define NUM 291
#define INBOUND 292
#define OUTBOUND 293
#define PF_IFNAME 294
#define PF_RSET 295
#define PF_RNR 296
#define PF_SRNR 297
#define PF_REASON 298
#define PF_ACTION 299
#define LINK 300
#define GEQ 301
#define LEQ 302
#define NEQ 303
#define ID 304
#define EID 305
#define HID 306
#define HID6 307
#define AID 308
#define LSH 309
#define RSH 310
#define LEN 311
#define IPV6 312
#define ICMPV6 313
#define AH 314
#define ESP 315
#define VLAN 316
#define MPLS 317
#define PPPOED 318
#define PPPOES 319
#define ISO 320
#define ESIS 321
#define CLNP 322
#define ISIS 323
#define L1 324
#define L2 325
#define IIH 326
#define LSP 327
#define SNP 328
#define CSNP 329
#define PSNP 330
#define STP 331
#define IPX 332
#define NETBEUI 333
#define LANE 334
#define LLC 335
#define METAC 336
#define BCC 337
#define SC 338
#define ILMIC 339
#define OAMF4EC 340
#define OAMF4SC 341
#define OAM 342
#define OAMF4 343
#define CONNECTMSG 344
#define METACONNECT 345
#define VPI 346
#define VCI 347
#define RADIO 348
#define FISU 349
#define LSSU 350
#define MSU 351
#define SIO 352
#define OPC 353
#define DPC 354
#define SLS 355
#define TYPE 356
#define SUBTYPE 357
#define AND 358
#define OR 359
#define UMINUS 360




/* Copy the first part of user declarations.  */
#line 1 "../libpcap/GRAMMAR.Y"

/*
 * Copyright (c) 1988, 1989, 1990, 1991, 1992, 1993, 1994, 1995, 1996
 *	The Regents of the University of California.  All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that: (1) source code distributions
 * retain the above copyright notice and this paragraph in its entirety, (2)
 * distributions including binary code include the above copyright notice and
 * this paragraph in its entirety in the documentation or other materials
 * provided with the distribution, and (3) all advertising materials mentioning
 * features or use of this software display the following acknowledgement:
 * ``This product includes software developed by the University of California,
 * Lawrence Berkeley Laboratory and its contributors.'' Neither the name of
 * the University nor the names of its contributors may be used to endorse
 * or promote products derived from this software without specific prior
 * written permission.
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND WITHOUT ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 *
 */
#ifndef lint
static const char rcsid[] _U_ =
    "@(#) $Header: /tcpdump/master/libpcap/grammar.y,v 1.99.2.1 2007/11/14 00:55:37 guy Exp $ (LBL)";
#endif

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#ifdef WIN32
#include <pcap-stdinc.h>
#else /* WIN32 */
#include <sys/types.h>
#include <sys/socket.h>
#endif /* WIN32 */

#include <stdlib.h>

#ifndef WIN32
#if __STDC__
struct mbuf;
struct rtentry;
#endif

#include <netinet/in.h>
#endif /* WIN32 */

#include <stdio.h>

#include "pcap-int.h"

#include "gencode.h"
#ifdef HAVE_NET_PFVAR_H
#include <net/if.h>
#include <net/pfvar.h>
#include <net/if_pflog.h>
#endif
#include "ieee80211.h"
#include <pcap/namedb.h>

#ifdef HAVE_OS_PROTO_H
#include "os-proto.h"
#endif

#define QSET(q, p, d, a) (q).proto = (p),\
			 (q).dir = (d),\
			 (q).addr = (a)

static const char *ieee80211_mgt_names[] = IEEE80211_MGT_SUBTYPE_NAMES;
static const char *ieee80211_ctl_names[] = IEEE80211_CTL_SUBTYPE_NAMES;
static const char *ieee80211_data_names[] = IEEE80211_DATA_SUBTYPE_NAMES;

int n_errors = 0;

static struct qual qerr = { Q_UNDEF, Q_UNDEF, Q_UNDEF, Q_UNDEF };

static void
yyerror(const char *msg)
{
	++n_errors;
	bpf_error("%s", msg);
	/* NOTREACHED */
}

#ifndef YYBISON
int yyparse(void);

int
pcap_parse()
{
	return (yyparse());
}
#endif

#ifdef HAVE_NET_PFVAR_H
static int
pfreason_to_num(const char *reason)
{
	const char *reasons[] = PFRES_NAMES;
	int i;

	for (i = 0; reasons[i]; i++) {
		if (pcap_strcasecmp(reason, reasons[i]) == 0)
			return (i);
	}
	bpf_error("unknown PF reason");
	/*NOTREACHED*/
}

static int
pfaction_to_num(const char *action)
{
	if (pcap_strcasecmp(action, "pass") == 0 ||
	    pcap_strcasecmp(action, "accept") == 0)
		return (PF_PASS);
	else if (pcap_strcasecmp(action, "drop") == 0 ||
		pcap_strcasecmp(action, "block") == 0)
		return (PF_DROP);
#if HAVE_PF_NAT_THROUGH_PF_NORDR
	else if (pcap_strcasecmp(action, "rdr") == 0)
		return (PF_RDR);
	else if (pcap_strcasecmp(action, "nat") == 0)
		return (PF_NAT);
	else if (pcap_strcasecmp(action, "binat") == 0)
		return (PF_BINAT);
	else if (pcap_strcasecmp(action, "nordr") == 0)
		return (PF_NORDR);
#endif
	else {
		bpf_error("unknown PF action");
		/*NOTREACHED*/
	}
}
#else /* !HAVE_NET_PFVAR_H */
static int
pfreason_to_num(const char *reason)
{
	bpf_error("libpcap was compiled on a machine without pf support");
	/*NOTREACHED*/

	/* this is to make the VC compiler happy */
	return -1;
}

static int
pfaction_to_num(const char *action)
{
	bpf_error("libpcap was compiled on a machine without pf support");
	/*NOTREACHED*/

	/* this is to make the VC compiler happy */
	return -1;
}
#endif /* HAVE_NET_PFVAR_H */


/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* Enabling the token table.  */
#ifndef YYTOKEN_TABLE
# define YYTOKEN_TABLE 0
#endif

#if ! defined (YYSTYPE) && ! defined (YYSTYPE_IS_DECLARED)
#line 159 "../libpcap/GRAMMAR.Y"
typedef union YYSTYPE {
	int i;
	bpf_u_int32 h;
	u_char *e;
	char *s;
	struct stmt *stmt;
	struct arth *a;
	struct {
		struct qual q;
		int atmfieldtype;
		int mtp3fieldtype;
		struct block *b;
	} blk;
	struct block *rblk;
} YYSTYPE;
/* Line 196 of yacc.c.  */
#line 477 "y.tab.c"
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif



/* Copy the second part of user declarations.  */


/* Line 219 of yacc.c.  */
#line 489 "y.tab.c"

#if ! defined (YYSIZE_T) && defined (__SIZE_TYPE__)
# define YYSIZE_T __SIZE_TYPE__
#endif
#if ! defined (YYSIZE_T) && defined (size_t)
# define YYSIZE_T size_t
#endif
#if ! defined (YYSIZE_T) && (defined (__STDC__) || defined (__cplusplus))
# include <stddef.h> /* INFRINGES ON USER NAME SPACE */
# define YYSIZE_T size_t
#endif
#if ! defined (YYSIZE_T)
# define YYSIZE_T unsigned int
#endif

#ifndef YY_
# if YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

#if ! defined (yyoverflow) || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if defined (__STDC__) || defined (__cplusplus)
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#     define YYINCLUDED_STDLIB_H
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning. */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (0)
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2005 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM ((YYSIZE_T) -1)
#  endif
#  ifdef __cplusplus
extern "C" {
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if (! defined (malloc) && ! defined (YYINCLUDED_STDLIB_H) \
	&& (defined (__STDC__) || defined (__cplusplus)))
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if (! defined (free) && ! defined (YYINCLUDED_STDLIB_H) \
	&& (defined (__STDC__) || defined (__cplusplus)))
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifdef __cplusplus
}
#  endif
# endif
#endif /* ! defined (yyoverflow) || YYERROR_VERBOSE */


#if (! defined (yyoverflow) \
     && (! defined (__cplusplus) \
	 || (defined (YYSTYPE_IS_TRIVIAL) && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  short int yyss;
  YYSTYPE yyvs;
  };

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (short int) + sizeof (YYSTYPE))			\
      + YYSTACK_GAP_MAXIMUM)

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined (__GNUC__) && 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  YYSIZE_T yyi;				\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (0)
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack)					\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack, Stack, yysize);				\
	Stack = &yyptr->Stack;						\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (0)

#endif

#if defined (__STDC__) || defined (__cplusplus)
   typedef signed char yysigned_char;
#else
   typedef short int yysigned_char;
#endif

/* YYFINAL -- State number of the termination state. */
#define YYFINAL  3
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   614

/* YYNTOKENS -- Number of terminals. */
#define YYNTOKENS  121
/* YYNNTS -- Number of nonterminals. */
#define YYNNTS  45
/* YYNRULES -- Number of rules. */
#define YYNRULES  195
/* YYNRULES -- Number of states. */
#define YYNSTATES  266

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   360

#define YYTRANSLATE(YYX)						\
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const unsigned char yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,   105,     2,     2,     2,     2,   107,     2,
     114,   113,   110,   108,     2,   109,     2,   111,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,   120,     2,
     117,   116,   115,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,   118,     2,   119,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,   106,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    83,    84,
      85,    86,    87,    88,    89,    90,    91,    92,    93,    94,
      95,    96,    97,    98,    99,   100,   101,   102,   103,   104,
     112
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const unsigned short int yyprhs[] =
{
       0,     0,     3,     6,     8,     9,    11,    15,    19,    23,
      27,    29,    31,    33,    35,    39,    41,    45,    49,    51,
      55,    57,    59,    61,    64,    66,    68,    70,    74,    78,
      80,    82,    84,    87,    91,    94,    97,   100,   103,   106,
     109,   113,   115,   119,   123,   125,   127,   129,   132,   134,
     137,   139,   140,   142,   144,   148,   152,   156,   160,   162,
     164,   166,   168,   170,   172,   174,   176,   178,   180,   182,
     184,   186,   188,   190,   192,   194,   196,   198,   200,   202,
     204,   206,   208,   210,   212,   214,   216,   218,   220,   222,
     224,   226,   228,   230,   232,   234,   236,   238,   240,   242,
     244,   246,   249,   252,   255,   258,   263,   265,   267,   270,
     272,   275,   277,   279,   281,   283,   286,   289,   292,   295,
     298,   301,   304,   309,   312,   315,   317,   319,   321,   323,
     325,   327,   329,   331,   333,   335,   337,   339,   341,   343,
     345,   347,   352,   359,   363,   367,   371,   375,   379,   383,
     387,   391,   394,   398,   400,   402,   404,   406,   408,   410,
     412,   416,   418,   420,   422,   424,   426,   428,   430,   432,
     434,   436,   438,   440,   442,   444,   446,   449,   452,   456,
     458,   460,   464,   466,   468,   470,   472,   474,   476,   478,
     480,   483,   486,   490,   492,   494
};

/* YYRHS -- A `-1'-separated list of the rules' RHS. */
static const short int yyrhs[] =
{
     122,     0,    -1,   123,   124,    -1,   123,    -1,    -1,   133,
      -1,   124,   125,   133,    -1,   124,   125,   127,    -1,   124,
     126,   133,    -1,   124,   126,   127,    -1,   103,    -1,   104,
      -1,   128,    -1,   154,    -1,   130,   131,   113,    -1,    49,
      -1,    51,   111,    36,    -1,    51,     8,    51,    -1,    51,
      -1,    52,   111,    36,    -1,    52,    -1,    50,    -1,    53,
      -1,   129,   127,    -1,   105,    -1,   114,    -1,   128,    -1,
     132,   125,   127,    -1,   132,   126,   127,    -1,   154,    -1,
     131,    -1,   135,    -1,   129,   133,    -1,   136,   137,   138,
      -1,   136,   137,    -1,   136,   138,    -1,   136,    13,    -1,
     136,    14,    -1,   136,   139,    -1,   134,   127,    -1,   130,
     124,   113,    -1,   140,    -1,   151,   149,   151,    -1,   151,
     150,   151,    -1,   141,    -1,   155,    -1,   156,    -1,   157,
     158,    -1,   161,    -1,   162,   163,    -1,   140,    -1,    -1,
       4,    -1,     3,    -1,     4,   104,     3,    -1,     3,   104,
       4,    -1,     4,   103,     3,    -1,     3,   103,     4,    -1,
       5,    -1,     7,    -1,     9,    -1,    10,    -1,     6,    -1,
      45,    -1,    18,    -1,    16,    -1,    17,    -1,    19,    -1,
      20,    -1,    21,    -1,    22,    -1,    23,    -1,    24,    -1,
      25,    -1,    26,    -1,    27,    -1,    28,    -1,    29,    -1,
      30,    -1,    31,    -1,    33,    -1,    32,    -1,    57,    -1,
      58,    -1,    59,    -1,    60,    -1,    65,    -1,    66,    -1,
      68,    -1,    69,    -1,    70,    -1,    71,    -1,    72,    -1,
      73,    -1,    75,    -1,    74,    -1,    67,    -1,    76,    -1,
      77,    -1,    78,    -1,    93,    -1,   136,    34,    -1,   136,
      35,    -1,    11,    36,    -1,    12,    36,    -1,    15,    36,
     153,    36,    -1,    37,    -1,    38,    -1,    61,   154,    -1,
      61,    -1,    62,   154,    -1,    62,    -1,    63,    -1,    64,
      -1,   142,    -1,   136,   143,    -1,    39,    49,    -1,    40,
      49,    -1,    41,    36,    -1,    42,    36,    -1,    43,   147,
      -1,    44,   148,    -1,   101,   144,   102,   145,    -1,   101,
     144,    -1,   102,   146,    -1,    36,    -1,    49,    -1,    36,
      -1,    49,    -1,    49,    -1,    36,    -1,    49,    -1,    49,
      -1,   115,    -1,    46,    -1,   116,    -1,    47,    -1,   117,
      -1,    48,    -1,   154,    -1,   152,    -1,   140,   118,   151,
     119,    -1,   140,   118,   151,   120,    36,   119,    -1,   151,
     108,   151,    -1,   151,   109,   151,    -1,   151,   110,   151,
      -1,   151,   111,   151,    -1,   151,   107,   151,    -1,   151,
     106,   151,    -1,   151,    54,   151,    -1,   151,    55,   151,
      -1,   109,   151,    -1,   130,   152,   113,    -1,    56,    -1,
     107,    -1,   106,    -1,   117,    -1,   115,    -1,   116,    -1,
      36,    -1,   130,   154,   113,    -1,    79,    -1,    80,    -1,
      81,    -1,    82,    -1,    85,    -1,    86,    -1,    83,    -1,
      84,    -1,    87,    -1,    88,    -1,    89,    -1,    90,    -1,
      91,    -1,    92,    -1,   159,    -1,   149,    36,    -1,   150,
      36,    -1,   130,   160,   113,    -1,    36,    -1,   159,    -1,
     160,   126,   159,    -1,    94,    -1,    95,    -1,    96,    -1,
      97,    -1,    98,    -1,    99,    -1,   100,    -1,   164,    -1,
     149,    36,    -1,   150,    36,    -1,   130,   165,   113,    -1,
      36,    -1,   164,    -1,   165,   126,   164,    -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const unsigned short int yyrline[] =
{
       0,   232,   232,   236,   238,   240,   241,   242,   243,   244,
     246,   248,   250,   251,   253,   255,   256,   258,   260,   273,
     282,   291,   300,   309,   311,   313,   315,   316,   317,   319,
     321,   323,   324,   326,   327,   328,   329,   330,   331,   333,
     334,   335,   336,   338,   340,   341,   342,   343,   344,   345,
     348,   349,   352,   353,   354,   355,   356,   357,   360,   361,
     362,   363,   366,   368,   369,   370,   371,   372,   373,   374,
     375,   376,   377,   378,   379,   380,   381,   382,   383,   384,
     385,   386,   387,   388,   389,   390,   391,   392,   393,   394,
     395,   396,   397,   398,   399,   400,   401,   402,   403,   404,
     405,   407,   408,   409,   410,   411,   412,   413,   414,   415,
     416,   417,   418,   419,   420,   421,   424,   425,   426,   427,
     428,   429,   432,   437,   440,   446,   447,   461,   462,   484,
     509,   510,   513,   516,   517,   518,   520,   521,   522,   524,
     525,   527,   528,   529,   530,   531,   532,   533,   534,   535,
     536,   537,   538,   539,   541,   542,   543,   544,   545,   547,
     548,   550,   551,   552,   553,   554,   555,   556,   557,   559,
     560,   561,   562,   565,   566,   568,   569,   570,   571,   573,
     580,   581,   584,   585,   586,   589,   590,   591,   592,   594,
     595,   596,   597,   599,   608,   609
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || YYTOKEN_TABLE
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals. */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "DST", "SRC", "HOST", "GATEWAY", "NET",
  "NETMASK", "PORT", "PORTRANGE", "LESS", "GREATER", "PROTO", "PROTOCHAIN",
  "CBYTE", "ARP", "RARP", "IP", "SCTP", "TCP", "UDP", "ICMP", "IGMP",
  "IGRP", "PIM", "VRRP", "ATALK", "AARP", "DECNET", "LAT", "SCA", "MOPRC",
  "MOPDL", "TK_BROADCAST", "TK_MULTICAST", "NUM", "INBOUND", "OUTBOUND",
  "PF_IFNAME", "PF_RSET", "PF_RNR", "PF_SRNR", "PF_REASON", "PF_ACTION",
  "LINK", "GEQ", "LEQ", "NEQ", "ID", "EID", "HID", "HID6", "AID", "LSH",
  "RSH", "LEN", "IPV6", "ICMPV6", "AH", "ESP", "VLAN", "MPLS", "PPPOED",
  "PPPOES", "ISO", "ESIS", "CLNP", "ISIS", "L1", "L2", "IIH", "LSP", "SNP",
  "CSNP", "PSNP", "STP", "IPX", "NETBEUI", "LANE", "LLC", "METAC", "BCC",
  "SC", "ILMIC", "OAMF4EC", "OAMF4SC", "OAM", "OAMF4", "CONNECTMSG",
  "METACONNECT", "VPI", "VCI", "RADIO", "FISU", "LSSU", "MSU", "SIO",
  "OPC", "DPC", "SLS", "TYPE", "SUBTYPE", "AND", "OR", "'!'", "'|'", "'&'",
  "'+'", "'-'", "'*'", "'/'", "UMINUS", "')'", "'('", "'>'", "'='", "'<'",
  "'['", "']'", "':'", "$accept", "prog", "null", "expr", "and", "or",
  "id", "nid", "not", "paren", "pid", "qid", "term", "head", "rterm",
  "pqual", "dqual", "aqual", "ndaqual", "pname", "other", "pfvar",
  "p80211", "type", "subtype", "type_subtype", "reason", "action", "relop",
  "irelop", "arth", "narth", "byteop", "pnum", "atmtype", "atmmultitype",
  "atmfield", "atmvalue", "atmfieldvalue", "atmlistvalue", "mtp2type",
  "mtp3field", "mtp3value", "mtp3fieldvalue", "mtp3listvalue", 0
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[YYLEX-NUM] -- Internal token number corresponding to
   token YYLEX-NUM.  */
static const unsigned short int yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312,   313,   314,
     315,   316,   317,   318,   319,   320,   321,   322,   323,   324,
     325,   326,   327,   328,   329,   330,   331,   332,   333,   334,
     335,   336,   337,   338,   339,   340,   341,   342,   343,   344,
     345,   346,   347,   348,   349,   350,   351,   352,   353,   354,
     355,   356,   357,   358,   359,    33,   124,    38,    43,    45,
      42,    47,   360,    41,    40,    62,    61,    60,    91,    93,
      58
};
# endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const unsigned char yyr1[] =
{
       0,   121,   122,   122,   123,   124,   124,   124,   124,   124,
     125,   126,   127,   127,   127,   128,   128,   128,   128,   128,
     128,   128,   128,   128,   129,   130,   131,   131,   131,   132,
     132,   133,   133,   134,   134,   134,   134,   134,   134,   135,
     135,   135,   135,   135,   135,   135,   135,   135,   135,   135,
     136,   136,   137,   137,   137,   137,   137,   137,   138,   138,
     138,   138,   139,   140,   140,   140,   140,   140,   140,   140,
     140,   140,   140,   140,   140,   140,   140,   140,   140,   140,
     140,   140,   140,   140,   140,   140,   140,   140,   140,   140,
     140,   140,   140,   140,   140,   140,   140,   140,   140,   140,
     140,   141,   141,   141,   141,   141,   141,   141,   141,   141,
     141,   141,   141,   141,   141,   141,   142,   142,   142,   142,
     142,   142,   143,   143,   143,   144,   144,   145,   145,   146,
     147,   147,   148,   149,   149,   149,   150,   150,   150,   151,
     151,   152,   152,   152,   152,   152,   152,   152,   152,   152,
     152,   152,   152,   152,   153,   153,   153,   153,   153,   154,
     154,   155,   155,   155,   155,   155,   155,   155,   155,   156,
     156,   156,   156,   157,   157,   158,   158,   158,   158,   159,
     160,   160,   161,   161,   161,   162,   162,   162,   162,   163,
     163,   163,   163,   164,   165,   165
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const unsigned char yyr2[] =
{
       0,     2,     2,     1,     0,     1,     3,     3,     3,     3,
       1,     1,     1,     1,     3,     1,     3,     3,     1,     3,
       1,     1,     1,     2,     1,     1,     1,     3,     3,     1,
       1,     1,     2,     3,     2,     2,     2,     2,     2,     2,
       3,     1,     3,     3,     1,     1,     1,     2,     1,     2,
       1,     0,     1,     1,     3,     3,     3,     3,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     2,     2,     2,     2,     4,     1,     1,     2,     1,
       2,     1,     1,     1,     1,     2,     2,     2,     2,     2,
       2,     2,     4,     2,     2,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     4,     6,     3,     3,     3,     3,     3,     3,     3,
       3,     2,     3,     1,     1,     1,     1,     1,     1,     1,
       3,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     2,     2,     3,     1,
       1,     3,     1,     1,     1,     1,     1,     1,     1,     1,
       2,     2,     3,     1,     1,     3
};

/* YYDEFACT[STATE-NAME] -- Default rule to reduce with in state
   STATE-NUM when YYTABLE doesn't specify something else to do.  Zero
   means the default is an error.  */
static const unsigned char yydefact[] =
{
       4,     0,    51,     1,     0,     0,     0,    65,    66,    64,
      67,    68,    69,    70,    71,    72,    73,    74,    75,    76,
      77,    78,    79,    81,    80,   159,   106,   107,     0,     0,
       0,     0,     0,     0,    63,   153,    82,    83,    84,    85,
     109,   111,   112,   113,    86,    87,    96,    88,    89,    90,
      91,    92,    93,    95,    94,    97,    98,    99,   161,   162,
     163,   164,   167,   168,   165,   166,   169,   170,   171,   172,
     173,   174,   100,   182,   183,   184,   185,   186,   187,   188,
      24,     0,    25,     2,    51,    51,     5,     0,    31,     0,
      50,    44,   114,     0,   140,   139,    45,    46,     0,    48,
       0,   103,   104,     0,   116,   117,   118,   119,   130,   131,
     120,   132,   121,     0,   108,   110,     0,     0,   151,    10,
      11,    51,    51,    32,     0,   140,   139,    15,    21,    18,
      20,    22,    39,    12,     0,     0,    13,    53,    52,    58,
      62,    59,    60,    61,    36,    37,   101,   102,     0,     0,
      34,    35,    38,   115,     0,   134,   136,   138,     0,     0,
       0,     0,     0,     0,     0,     0,   133,   135,   137,     0,
       0,   179,     0,     0,     0,    47,   175,   193,     0,     0,
       0,    49,   189,   155,   154,   157,   158,   156,     0,     0,
       0,     7,    51,    51,     6,   139,     9,     8,    40,   152,
     160,     0,     0,     0,    23,    26,    30,     0,    29,     0,
       0,     0,     0,   125,   126,   123,   129,   124,    33,     0,
     149,   150,   148,   147,   143,   144,   145,   146,    42,    43,
     180,     0,   176,   177,   194,     0,   190,   191,   105,   139,
      17,    16,    19,    14,     0,     0,    57,    55,    56,    54,
       0,   141,     0,   178,     0,   192,     0,    27,    28,   127,
     128,   122,     0,   181,   195,   142
};

/* YYDEFGOTO[NTERM-NUM]. */
static const short int yydefgoto[] =
{
      -1,     1,     2,   124,   121,   122,   204,   133,   134,   116,
     206,   207,    86,    87,    88,    89,   150,   151,   152,   117,
      91,    92,   153,   215,   261,   217,   110,   112,   169,   170,
      93,    94,   188,    95,    96,    97,    98,   175,   176,   231,
      99,   100,   181,   182,   235
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -189
static const short int yypact[] =
{
    -189,    33,   196,  -189,    13,    15,    32,  -189,  -189,  -189,
    -189,  -189,  -189,  -189,  -189,  -189,  -189,  -189,  -189,  -189,
    -189,  -189,  -189,  -189,  -189,  -189,  -189,  -189,    23,    27,
      52,    67,   -28,    35,  -189,  -189,  -189,  -189,  -189,  -189,
     -13,   -13,  -189,  -189,  -189,  -189,  -189,  -189,  -189,  -189,
    -189,  -189,  -189,  -189,  -189,  -189,  -189,  -189,  -189,  -189,
    -189,  -189,  -189,  -189,  -189,  -189,  -189,  -189,  -189,  -189,
    -189,  -189,  -189,  -189,  -189,  -189,  -189,  -189,  -189,  -189,
    -189,   495,  -189,    40,   396,   396,  -189,     4,  -189,    60,
       3,  -189,  -189,   490,  -189,  -189,  -189,  -189,   130,  -189,
     134,  -189,  -189,   -89,  -189,  -189,  -189,  -189,  -189,  -189,
    -189,  -189,  -189,   -13,  -189,  -189,   495,   -10,  -189,  -189,
    -189,   296,   296,  -189,   -69,    -3,    10,  -189,  -189,     2,
       6,  -189,  -189,  -189,     4,     4,  -189,    48,    50,  -189,
    -189,  -189,  -189,  -189,  -189,  -189,  -189,  -189,   -24,    66,
      70,  -189,  -189,  -189,   495,  -189,  -189,  -189,   495,   495,
     495,   495,   495,   495,   495,   495,  -189,  -189,  -189,   495,
     495,  -189,    94,   109,   112,  -189,  -189,  -189,   127,   128,
     129,  -189,  -189,  -189,  -189,  -189,  -189,  -189,   131,    10,
      95,  -189,   296,   296,  -189,     1,  -189,  -189,  -189,  -189,
    -189,   117,   133,   135,  -189,  -189,    59,    40,    10,   169,
     170,   172,   176,  -189,  -189,    81,  -189,  -189,  -189,   475,
     -49,   -49,   503,   289,    45,    45,  -189,  -189,    95,    95,
    -189,   -93,  -189,  -189,  -189,   -82,  -189,  -189,  -189,    21,
    -189,  -189,  -189,  -189,     4,     4,  -189,  -189,  -189,  -189,
     -20,  -189,   148,  -189,    94,  -189,   127,  -189,  -189,  -189,
    -189,  -189,    68,  -189,  -189,  -189
};

/* YYPGOTO[NTERM-NUM].  */
static const short int yypgoto[] =
{
    -189,  -189,  -189,   183,   -21,  -188,   -85,  -122,     5,    -2,
    -189,  -189,   -80,  -189,  -189,  -189,  -189,    38,  -189,     7,
    -189,  -189,  -189,  -189,  -189,  -189,  -189,  -189,   -68,   -52,
     -23,   -71,  -189,   -35,  -189,  -189,  -189,  -189,  -157,  -189,
    -189,  -189,  -189,  -154,  -189
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If zero, do what YYDEFACT says.
   If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -42
static const short int yytable[] =
{
      85,   -13,   132,   -41,   123,   114,   115,    84,   108,    90,
     201,   120,   213,   205,   125,   230,   259,   183,   184,   245,
     253,   109,   120,    25,   234,   214,   185,   186,   187,   260,
     173,   255,   179,     3,   119,   120,   191,   196,   113,   113,
      25,   194,   197,   254,   198,   125,   174,   256,   180,   101,
     126,   102,   136,   127,   128,   129,   130,   131,   118,   162,
     163,   164,   165,   137,   138,   139,   140,   141,   103,   142,
     143,   205,   104,   144,   145,   139,   105,   141,   189,   142,
     143,   126,    85,    85,   111,   135,   195,   195,   106,    84,
      84,    90,    90,   190,   146,   147,   172,   263,   178,   136,
     208,    82,   264,   107,   -13,   -13,   -41,   -41,   154,    80,
     199,   113,   123,   202,   -13,   216,   -41,   203,    82,   193,
     193,   154,   125,   200,   -29,   -29,   192,   192,    90,    90,
     171,   219,   135,   113,   200,   220,   221,   222,   223,   224,
     225,   226,   227,   119,   120,   232,   228,   229,   233,   158,
     159,   209,   210,   211,   212,   164,   165,   195,   239,   257,
     258,   148,   149,   177,   236,   237,   171,   238,   240,   241,
     177,   242,   243,   246,   247,   248,   155,   156,   157,   249,
     155,   156,   157,   250,   262,    83,   244,   265,   218,     0,
     193,    85,     0,     0,     0,     0,    -3,   192,   192,    90,
      90,   160,   161,   162,   163,   164,   165,     4,     5,   136,
     136,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
       0,     0,    25,    26,    27,    28,    29,    30,    31,    32,
      33,    34,   135,   135,    82,   166,   167,   168,    82,   166,
     167,   168,    35,    36,    37,    38,    39,    40,    41,    42,
      43,    44,    45,    46,    47,    48,    49,    50,    51,    52,
      53,    54,    55,    56,    57,    58,    59,    60,    61,    62,
      63,    64,    65,    66,    67,    68,    69,    70,    71,    72,
      73,    74,    75,    76,    77,    78,    79,     0,     0,     0,
       0,    80,     0,     0,     0,    81,     0,     4,     5,     0,
      82,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
       0,     0,    25,    26,    27,    28,    29,    30,    31,    32,
      33,    34,     0,   158,   159,   127,   128,   129,   130,   131,
       0,     0,    35,    36,    37,    38,    39,    40,    41,    42,
      43,    44,    45,    46,    47,    48,    49,    50,    51,    52,
      53,    54,    55,    56,    57,    58,    59,    60,    61,    62,
      63,    64,    65,    66,    67,    68,    69,    70,    71,    72,
      73,    74,    75,    76,    77,    78,    79,   162,   163,   164,
     165,    80,     0,     0,     0,    81,     0,     4,     5,     0,
      82,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
       0,     0,    25,    26,    27,    28,    29,    30,    31,    32,
      33,    34,     0,     0,     0,     0,     0,     0,     0,     0,
       0,     0,    35,    36,    37,    38,    39,    40,    41,    42,
      43,    44,    45,    46,    47,    48,    49,    50,    51,    52,
      53,    54,    55,    56,    57,    58,    59,    60,    61,    62,
      63,    64,    65,    66,    67,    68,    69,    70,    71,    72,
      73,    74,    75,    76,    77,    78,    79,     0,     0,     0,
       0,    80,     0,     0,     0,    81,     0,     0,     0,     0,
      82,     7,     8,     9,    10,    11,    12,    13,    14,    15,
      16,    17,    18,    19,    20,    21,    22,    23,    24,   158,
     159,    25,     0,     0,     0,     0,   155,   156,   157,     0,
      34,     0,     0,     0,   158,   159,     0,     0,     0,     0,
       0,    35,    36,    37,    38,    39,     0,   158,   159,     0,
      44,    45,    46,    47,    48,    49,    50,    51,    52,    53,
      54,    55,    56,    57,     0,     0,     0,     0,     0,     0,
       0,   160,   161,   162,   163,   164,   165,     0,    72,     0,
       0,     0,     0,     0,   251,   252,   160,   161,   162,   163,
     164,   165,     0,     0,    81,   166,   167,   168,     0,    82,
     161,   162,   163,   164,   165
};

static const short int yycheck[] =
{
       2,     0,    87,     0,    84,    40,    41,     2,    36,     2,
       8,   104,    36,   135,    85,   172,    36,   106,   107,   207,
     113,    49,   104,    36,   178,    49,   115,   116,   117,    49,
      98,   113,   100,     0,   103,   104,   121,   122,    40,    41,
      36,   121,   122,   231,   113,   116,    98,   235,   100,    36,
      85,    36,    87,    49,    50,    51,    52,    53,    81,   108,
     109,   110,   111,     3,     4,     5,     6,     7,    36,     9,
      10,   193,    49,    13,    14,     5,    49,     7,   113,     9,
      10,   116,    84,    85,    49,    87,   121,   122,    36,    84,
      85,    84,    85,   116,    34,    35,    98,   254,   100,   134,
     135,   114,   256,    36,   103,   104,   103,   104,   118,   105,
     113,   113,   192,   111,   113,    49,   113,   111,   114,   121,
     122,   118,   193,   113,   103,   104,   121,   122,   121,   122,
      36,   154,   134,   135,   113,   158,   159,   160,   161,   162,
     163,   164,   165,   103,   104,    36,   169,   170,    36,    54,
      55,   103,   104,   103,   104,   110,   111,   192,   193,   244,
     245,   101,   102,    36,    36,    36,    36,    36,    51,    36,
      36,    36,   113,     4,     4,     3,    46,    47,    48,     3,
      46,    47,    48,   102,    36,     2,   207,   119,   150,    -1,
     192,   193,    -1,    -1,    -1,    -1,     0,   192,   193,   192,
     193,   106,   107,   108,   109,   110,   111,    11,    12,   244,
     245,    15,    16,    17,    18,    19,    20,    21,    22,    23,
      24,    25,    26,    27,    28,    29,    30,    31,    32,    33,
      -1,    -1,    36,    37,    38,    39,    40,    41,    42,    43,
      44,    45,   244,   245,   114,   115,   116,   117,   114,   115,
     116,   117,    56,    57,    58,    59,    60,    61,    62,    63,
      64,    65,    66,    67,    68,    69,    70,    71,    72,    73,
      74,    75,    76,    77,    78,    79,    80,    81,    82,    83,
      84,    85,    86,    87,    88,    89,    90,    91,    92,    93,
      94,    95,    96,    97,    98,    99,   100,    -1,    -1,    -1,
      -1,   105,    -1,    -1,    -1,   109,    -1,    11,    12,    -1,
     114,    15,    16,    17,    18,    19,    20,    21,    22,    23,
      24,    25,    26,    27,    28,    29,    30,    31,    32,    33,
      -1,    -1,    36,    37,    38,    39,    40,    41,    42,    43,
      44,    45,    -1,    54,    55,    49,    50,    51,    52,    53,
      -1,    -1,    56,    57,    58,    59,    60,    61,    62,    63,
      64,    65,    66,    67,    68,    69,    70,    71,    72,    73,
      74,    75,    76,    77,    78,    79,    80,    81,    82,    83,
      84,    85,    86,    87,    88,    89,    90,    91,    92,    93,
      94,    95,    96,    97,    98,    99,   100,   108,   109,   110,
     111,   105,    -1,    -1,    -1,   109,    -1,    11,    12,    -1,
     114,    15,    16,    17,    18,    19,    20,    21,    22,    23,
      24,    25,    26,    27,    28,    29,    30,    31,    32,    33,
      -1,    -1,    36,    37,    38,    39,    40,    41,    42,    43,
      44,    45,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,    -1,    56,    57,    58,    59,    60,    61,    62,    63,
      64,    65,    66,    67,    68,    69,    70,    71,    72,    73,
      74,    75,    76,    77,    78,    79,    80,    81,    82,    83,
      84,    85,    86,    87,    88,    89,    90,    91,    92,    93,
      94,    95,    96,    97,    98,    99,   100,    -1,    -1,    -1,
      -1,   105,    -1,    -1,    -1,   109,    -1,    -1,    -1,    -1,
     114,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    54,
      55,    36,    -1,    -1,    -1,    -1,    46,    47,    48,    -1,
      45,    -1,    -1,    -1,    54,    55,    -1,    -1,    -1,    -1,
      -1,    56,    57,    58,    59,    60,    -1,    54,    55,    -1,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    -1,    -1,    -1,    -1,    -1,    -1,
      -1,   106,   107,   108,   109,   110,   111,    -1,    93,    -1,
      -1,    -1,    -1,    -1,   119,   120,   106,   107,   108,   109,
     110,   111,    -1,    -1,   109,   115,   116,   117,    -1,   114,
     107,   108,   109,   110,   111
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const unsigned char yystos[] =
{
       0,   122,   123,     0,    11,    12,    15,    16,    17,    18,
      19,    20,    21,    22,    23,    24,    25,    26,    27,    28,
      29,    30,    31,    32,    33,    36,    37,    38,    39,    40,
      41,    42,    43,    44,    45,    56,    57,    58,    59,    60,
      61,    62,    63,    64,    65,    66,    67,    68,    69,    70,
      71,    72,    73,    74,    75,    76,    77,    78,    79,    80,
      81,    82,    83,    84,    85,    86,    87,    88,    89,    90,
      91,    92,    93,    94,    95,    96,    97,    98,    99,   100,
     105,   109,   114,   124,   129,   130,   133,   134,   135,   136,
     140,   141,   142,   151,   152,   154,   155,   156,   157,   161,
     162,    36,    36,    36,    49,    49,    36,    36,    36,    49,
     147,    49,   148,   130,   154,   154,   130,   140,   151,   103,
     104,   125,   126,   133,   124,   152,   154,    49,    50,    51,
      52,    53,   127,   128,   129,   130,   154,     3,     4,     5,
       6,     7,     9,    10,    13,    14,    34,    35,   101,   102,
     137,   138,   139,   143,   118,    46,    47,    48,    54,    55,
     106,   107,   108,   109,   110,   111,   115,   116,   117,   149,
     150,    36,   130,   149,   150,   158,   159,    36,   130,   149,
     150,   163,   164,   106,   107,   115,   116,   117,   153,   154,
     151,   127,   129,   130,   133,   154,   127,   133,   113,   113,
     113,     8,   111,   111,   127,   128,   131,   132,   154,   103,
     104,   103,   104,    36,    49,   144,    49,   146,   138,   151,
     151,   151,   151,   151,   151,   151,   151,   151,   151,   151,
     159,   160,    36,    36,   164,   165,    36,    36,    36,   154,
      51,    36,    36,   113,   125,   126,     4,     4,     3,     3,
     102,   119,   120,   113,   126,   113,   126,   127,   127,    36,
      49,   145,    36,   159,   164,   119
};

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		(-2)
#define YYEOF		0

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrorlab


/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */

#define YYFAIL		goto yyerrlab

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yytoken = YYTRANSLATE (yychar);				\
      YYPOPSTACK;						\
      goto yybackup;						\
    }								\
  else								\
    {								\
      yyerror (YY_("syntax error: cannot back up")); \
      YYERROR;							\
    }								\
while (0)


#define YYTERROR	1
#define YYERRCODE	256


/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#define YYRHSLOC(Rhs, K) ((Rhs)[K])
#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)				\
    do									\
      if (N)								\
	{								\
	  (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;	\
	  (Current).first_column = YYRHSLOC (Rhs, 1).first_column;	\
	  (Current).last_line    = YYRHSLOC (Rhs, N).last_line;		\
	  (Current).last_column  = YYRHSLOC (Rhs, N).last_column;	\
	}								\
      else								\
	{								\
	  (Current).first_line   = (Current).last_line   =		\
	    YYRHSLOC (Rhs, 0).last_line;				\
	  (Current).first_column = (Current).last_column =		\
	    YYRHSLOC (Rhs, 0).last_column;				\
	}								\
    while (0)
#endif


/* YY_LOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

#ifndef YY_LOCATION_PRINT
# if YYLTYPE_IS_TRIVIAL
#  define YY_LOCATION_PRINT(File, Loc)			\
     fprintf (File, "%d.%d-%d.%d",			\
              (Loc).first_line, (Loc).first_column,	\
              (Loc).last_line,  (Loc).last_column)
# else
#  define YY_LOCATION_PRINT(File, Loc) ((void) 0)
# endif
#endif


/* YYLEX -- calling `yylex' with the right arguments.  */

#ifdef YYLEX_PARAM
# define YYLEX yylex (YYLEX_PARAM)
#else
# define YYLEX yylex ()
#endif

/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (0)

# define YY_SYMBOL_PRINT(Title, Type, Value, Location)		\
do {								\
  if (yydebug)							\
    {								\
      YYFPRINTF (stderr, "%s ", Title);				\
      yysymprint (stderr,					\
                  Type, Value);	\
      YYFPRINTF (stderr, "\n");					\
    }								\
} while (0)

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yy_stack_print (short int *bottom, short int *top)
#else
static void
yy_stack_print (bottom, top)
    short int *bottom;
    short int *top;
#endif
{
  YYFPRINTF (stderr, "Stack now");
  for (/* Nothing. */; bottom <= top; ++bottom)
    YYFPRINTF (stderr, " %d", *bottom);
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)				\
do {								\
  if (yydebug)							\
    yy_stack_print ((Bottom), (Top));				\
} while (0)


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yy_reduce_print (int yyrule)
#else
static void
yy_reduce_print (yyrule)
    int yyrule;
#endif
{
  int yyi;
  unsigned long int yylno = yyrline[yyrule];
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu), ",
             yyrule - 1, yylno);
  /* Print the symbols being reduced, and their result.  */
  for (yyi = yyprhs[yyrule]; 0 <= yyrhs[yyi]; yyi++)
    YYFPRINTF (stderr, "%s ", yytname[yyrhs[yyi]]);
  YYFPRINTF (stderr, "-> %s\n", yytname[yyr1[yyrule]]);
}

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug)				\
    yy_reduce_print (Rule);		\
} while (0)

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif



#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined (__GLIBC__) && defined (_STRING_H)
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
static YYSIZE_T
#   if defined (__STDC__) || defined (__cplusplus)
yystrlen (const char *yystr)
#   else
yystrlen (yystr)
     const char *yystr;
#   endif
{
  const char *yys = yystr;

  while (*yys++ != '\0')
    continue;

  return yys - yystr - 1;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined (__GLIBC__) && defined (_STRING_H) && defined (_GNU_SOURCE)
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
static char *
#   if defined (__STDC__) || defined (__cplusplus)
yystpcpy (char *yydest, const char *yysrc)
#   else
yystpcpy (yydest, yysrc)
     char *yydest;
     const char *yysrc;
#   endif
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      size_t yyn = 0;
      char const *yyp = yystr;

      for (;;)
	switch (*++yyp)
	  {
	  case '\'':
	  case ',':
	    goto do_not_strip_quotes;

	  case '\\':
	    if (*++yyp != '\\')
	      goto do_not_strip_quotes;
	    /* Fall through.  */
	  default:
	    if (yyres)
	      yyres[yyn] = *yyp;
	    yyn++;
	    break;

	  case '"':
	    if (yyres)
	      yyres[yyn] = '\0';
	    return yyn;
	  }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

#endif /* YYERROR_VERBOSE */



#if YYDEBUG
/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yysymprint (FILE *yyoutput, int yytype, YYSTYPE *yyvaluep)
#else
static void
yysymprint (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE *yyvaluep;
#endif
{
  /* Pacify ``unused variable'' warnings.  */
  (void) yyvaluep;

  if (yytype < YYNTOKENS)
    YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);


# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# endif
  switch (yytype)
    {
      default:
        break;
    }
  YYFPRINTF (yyoutput, ")");
}

#endif /* ! YYDEBUG */
/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

#if defined (__STDC__) || defined (__cplusplus)
static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep)
#else
static void
yydestruct (yymsg, yytype, yyvaluep)
    const char *yymsg;
    int yytype;
    YYSTYPE *yyvaluep;
#endif
{
  /* Pacify ``unused variable'' warnings.  */
  (void) yyvaluep;

  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  switch (yytype)
    {

      default:
        break;
    }
}


/* Prevent warnings from -Wmissing-prototypes.  */

#ifdef YYPARSE_PARAM
# if defined (__STDC__) || defined (__cplusplus)
int yyparse (void *YYPARSE_PARAM);
# else
int yyparse ();
# endif
#else /* ! YYPARSE_PARAM */
#if defined (__STDC__) || defined (__cplusplus)
int yyparse (void);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */



/* The look-ahead symbol.  */
int yychar;

/* The semantic value of the look-ahead symbol.  */
YYSTYPE yylval;

/* Number of syntax errors so far.  */
int yynerrs;



/*----------.
| yyparse.  |
`----------*/

#ifdef YYPARSE_PARAM
# if defined (__STDC__) || defined (__cplusplus)
int yyparse (void *YYPARSE_PARAM)
# else
int yyparse (YYPARSE_PARAM)
  void *YYPARSE_PARAM;
# endif
#else /* ! YYPARSE_PARAM */
#if defined (__STDC__) || defined (__cplusplus)
int
yyparse (void)
#else
int
yyparse ()
    ;
#endif
#endif
{
  
  int yystate;
  int yyn;
  int yyresult;
  /* Number of tokens to shift before error messages enabled.  */
  int yyerrstatus;
  /* Look-ahead token as an internal (translated) token number.  */
  int yytoken = 0;

  /* Three stacks and their tools:
     `yyss': related to states,
     `yyvs': related to semantic values,
     `yyls': related to locations.

     Refer to the stacks thru separate pointers, to allow yyoverflow
     to reallocate them elsewhere.  */

  /* The state stack.  */
  short int yyssa[YYINITDEPTH];
  short int *yyss = yyssa;
  short int *yyssp;

  /* The semantic value stack.  */
  YYSTYPE yyvsa[YYINITDEPTH];
  YYSTYPE *yyvs = yyvsa;
  YYSTYPE *yyvsp;



#define YYPOPSTACK   (yyvsp--, yyssp--)

  YYSIZE_T yystacksize = YYINITDEPTH;

  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;


  /* When reducing, the number of symbols on the RHS of the reduced
     rule.  */
  int yylen;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss;
  yyvsp = yyvs;

  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed. so pushing a state here evens the stacks.
     */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack. Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	short int *yyss1 = yyss;


	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  This used to be a
	   conditional around just the two extra args, but that might
	   be undefined if yyoverflow is a macro.  */
	yyoverflow (YY_("memory exhausted"),
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),

		    &yystacksize);

	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
	goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
	yystacksize = YYMAXDEPTH;

      {
	short int *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyexhaustedlab;
	YYSTACK_RELOCATE (yyss);
	YYSTACK_RELOCATE (yyvs);

#  undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;


      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

/* Do appropriate processing given the current state.  */
/* Read a look-ahead token if we need one and don't already have one.  */
/* yyresume: */

  /* First try to decide what to do without reference to look-ahead token.  */

  yyn = yypact[yystate];
  if (yyn == YYPACT_NINF)
    goto yydefault;

  /* Not known => get a look-ahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid look-ahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yyn == 0 || yyn == YYTABLE_NINF)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Shift the look-ahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the token being shifted unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  *++yyvsp = yylval;


  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  yystate = yyn;
  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 2:
#line 233 "../libpcap/GRAMMAR.Y"
    {
	finish_parse((yyvsp[0].blk).b);
}
    break;

  case 4:
#line 238 "../libpcap/GRAMMAR.Y"
    { (yyval.blk).q = qerr; }
    break;

  case 6:
#line 241 "../libpcap/GRAMMAR.Y"
    { gen_and((yyvsp[-2].blk).b, (yyvsp[0].blk).b); (yyval.blk) = (yyvsp[0].blk); }
    break;

  case 7:
#line 242 "../libpcap/GRAMMAR.Y"
    { gen_and((yyvsp[-2].blk).b, (yyvsp[0].blk).b); (yyval.blk) = (yyvsp[0].blk); }
    break;

  case 8:
#line 243 "../libpcap/GRAMMAR.Y"
    { gen_or((yyvsp[-2].blk).b, (yyvsp[0].blk).b); (yyval.blk) = (yyvsp[0].blk); }
    break;

  case 9:
#line 244 "../libpcap/GRAMMAR.Y"
    { gen_or((yyvsp[-2].blk).b, (yyvsp[0].blk).b); (yyval.blk) = (yyvsp[0].blk); }
    break;

  case 10:
#line 246 "../libpcap/GRAMMAR.Y"
    { (yyval.blk) = (yyvsp[-1].blk); }
    break;

  case 11:
#line 248 "../libpcap/GRAMMAR.Y"
    { (yyval.blk) = (yyvsp[-1].blk); }
    break;

  case 13:
#line 251 "../libpcap/GRAMMAR.Y"
    { (yyval.blk).b = gen_ncode(NULL, (bpf_u_int32)(yyvsp[0].i),
						   (yyval.blk).q = (yyvsp[-1].blk).q); }
    break;

  case 14:
#line 253 "../libpcap/GRAMMAR.Y"
    { (yyval.blk) = (yyvsp[-1].blk); }
    break;

  case 15:
#line 255 "../libpcap/GRAMMAR.Y"
    { (yyval.blk).b = gen_scode((yyvsp[0].s), (yyval.blk).q = (yyvsp[-1].blk).q); }
    break;

  case 16:
#line 256 "../libpcap/GRAMMAR.Y"
    { (yyval.blk).b = gen_mcode((yyvsp[-2].s), NULL, (yyvsp[0].i),
				    (yyval.blk).q = (yyvsp[-3].blk).q); }
    break;

  case 17:
#line 258 "../libpcap/GRAMMAR.Y"
    { (yyval.blk).b = gen_mcode((yyvsp[-2].s), (yyvsp[0].s), 0,
				    (yyval.blk).q = (yyvsp[-3].blk).q); }
    break;

  case 18:
#line 260 "../libpcap/GRAMMAR.Y"
    {
				  /* Decide how to parse HID based on proto */
				  (yyval.blk).q = (yyvsp[-1].blk).q;
				  if ((yyval.blk).q.addr == Q_PORT)
				  	bpf_error("'port' modifier applied to ip host");
				  else if ((yyval.blk).q.addr == Q_PORTRANGE)
				  	bpf_error("'portrange' modifier applied to ip host");
				  else if ((yyval.blk).q.addr == Q_PROTO)
				  	bpf_error("'proto' modifier applied to ip host");
				  else if ((yyval.blk).q.addr == Q_PROTOCHAIN)
				  	bpf_error("'protochain' modifier applied to ip host");
				  (yyval.blk).b = gen_ncode((yyvsp[0].s), 0, (yyval.blk).q);
				}
    break;

  case 19:
#line 273 "../libpcap/GRAMMAR.Y"
    {
#ifdef INET6
				  (yyval.blk).b = gen_mcode6((yyvsp[-2].s), NULL, (yyvsp[0].i),
				    (yyval.blk).q = (yyvsp[-3].blk).q);
#else
				  bpf_error("'ip6addr/prefixlen' not supported "
					"in this configuration");
#endif /*INET6*/
				}
    break;

  case 20:
#line 282 "../libpcap/GRAMMAR.Y"
    {
#ifdef INET6
				  (yyval.blk).b = gen_mcode6((yyvsp[0].s), 0, 128,
				    (yyval.blk).q = (yyvsp[-1].blk).q);
#else
				  bpf_error("'ip6addr' not supported "
					"in this configuration");
#endif /*INET6*/
				}
    break;

  case 21:
#line 291 "../libpcap/GRAMMAR.Y"
    { 
				  (yyval.blk).b = gen_ecode((yyvsp[0].e), (yyval.blk).q = (yyvsp[-1].blk).q);
				  /*
				   * $1 was allocated by "pcap_ether_aton()",
				   * so we must free it now that we're done
				   * with it.
				   */
				  free((yyvsp[0].e));
				}
    break;

  case 22:
#line 300 "../libpcap/GRAMMAR.Y"
    {
				  (yyval.blk).b = gen_acode((yyvsp[0].e), (yyval.blk).q = (yyvsp[-1].blk).q);
				  /*
				   * $1 was allocated by "pcap_ether_aton()",
				   * so we must free it now that we're done
				   * with it.
				   */
				  free((yyvsp[0].e));
				}
    break;

  case 23:
#line 309 "../libpcap/GRAMMAR.Y"
    { gen_not((yyvsp[0].blk).b); (yyval.blk) = (yyvsp[0].blk); }
    break;

  case 24:
#line 311 "../libpcap/GRAMMAR.Y"
    { (yyval.blk) = (yyvsp[-1].blk); }
    break;

  case 25:
#line 313 "../libpcap/GRAMMAR.Y"
    { (yyval.blk) = (yyvsp[-1].blk); }
    break;

  case 27:
#line 316 "../libpcap/GRAMMAR.Y"
    { gen_and((yyvsp[-2].blk).b, (yyvsp[0].blk).b); (yyval.blk) = (yyvsp[0].blk); }
    break;

  case 28:
#line 317 "../libpcap/GRAMMAR.Y"
    { gen_or((yyvsp[-2].blk).b, (yyvsp[0].blk).b); (yyval.blk) = (yyvsp[0].blk); }
    break;

  case 29:
#line 319 "../libpcap/GRAMMAR.Y"
    { (yyval.blk).b = gen_ncode(NULL, (bpf_u_int32)(yyvsp[0].i),
						   (yyval.blk).q = (yyvsp[-1].blk).q); }
    break;

  case 32:
#line 324 "../libpcap/GRAMMAR.Y"
    { gen_not((yyvsp[0].blk).b); (yyval.blk) = (yyvsp[0].blk); }
    break;

  case 33:
#line 326 "../libpcap/GRAMMAR.Y"
    { QSET((yyval.blk).q, (yyvsp[-2].i), (yyvsp[-1].i), (yyvsp[0].i)); }
    break;

  case 34:
#line 327 "../libpcap/GRAMMAR.Y"
    { QSET((yyval.blk).q, (yyvsp[-1].i), (yyvsp[0].i), Q_DEFAULT); }
    break;

  case 35:
#line 328 "../libpcap/GRAMMAR.Y"
    { QSET((yyval.blk).q, (yyvsp[-1].i), Q_DEFAULT, (yyvsp[0].i)); }
    break;

  case 36:
#line 329 "../libpcap/GRAMMAR.Y"
    { QSET((yyval.blk).q, (yyvsp[-1].i), Q_DEFAULT, Q_PROTO); }
    break;

  case 37:
#line 330 "../libpcap/GRAMMAR.Y"
    { QSET((yyval.blk).q, (yyvsp[-1].i), Q_DEFAULT, Q_PROTOCHAIN); }
    break;

  case 38:
#line 331 "../libpcap/GRAMMAR.Y"
    { QSET((yyval.blk).q, (yyvsp[-1].i), Q_DEFAULT, (yyvsp[0].i)); }
    break;

  case 39:
#line 333 "../libpcap/GRAMMAR.Y"
    { (yyval.blk) = (yyvsp[0].blk); }
    break;

  case 40:
#line 334 "../libpcap/GRAMMAR.Y"
    { (yyval.blk).b = (yyvsp[-1].blk).b; (yyval.blk).q = (yyvsp[-2].blk).q; }
    break;

  case 41:
#line 335 "../libpcap/GRAMMAR.Y"
    { (yyval.blk).b = gen_proto_abbrev((yyvsp[0].i)); (yyval.blk).q = qerr; }
    break;

  case 42:
#line 336 "../libpcap/GRAMMAR.Y"
    { (yyval.blk).b = gen_relation((yyvsp[-1].i), (yyvsp[-2].a), (yyvsp[0].a), 0);
				  (yyval.blk).q = qerr; }
    break;

  case 43:
#line 338 "../libpcap/GRAMMAR.Y"
    { (yyval.blk).b = gen_relation((yyvsp[-1].i), (yyvsp[-2].a), (yyvsp[0].a), 1);
				  (yyval.blk).q = qerr; }
    break;

  case 44:
#line 340 "../libpcap/GRAMMAR.Y"
    { (yyval.blk).b = (yyvsp[0].rblk); (yyval.blk).q = qerr; }
    break;

  case 45:
#line 341 "../libpcap/GRAMMAR.Y"
    { (yyval.blk).b = gen_atmtype_abbrev((yyvsp[0].i)); (yyval.blk).q = qerr; }
    break;

  case 46:
#line 342 "../libpcap/GRAMMAR.Y"
    { (yyval.blk).b = gen_atmmulti_abbrev((yyvsp[0].i)); (yyval.blk).q = qerr; }
    break;

  case 47:
#line 343 "../libpcap/GRAMMAR.Y"
    { (yyval.blk).b = (yyvsp[0].blk).b; (yyval.blk).q = qerr; }
    break;

  case 48:
#line 344 "../libpcap/GRAMMAR.Y"
    { (yyval.blk).b = gen_mtp2type_abbrev((yyvsp[0].i)); (yyval.blk).q = qerr; }
    break;

  case 49:
#line 345 "../libpcap/GRAMMAR.Y"
    { (yyval.blk).b = (yyvsp[0].blk).b; (yyval.blk).q = qerr; }
    break;

  case 51:
#line 349 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = Q_DEFAULT; }
    break;

  case 52:
#line 352 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = Q_SRC; }
    break;

  case 53:
#line 353 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = Q_DST; }
    break;

  case 54:
#line 354 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = Q_OR; }
    break;

  case 55:
#line 355 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = Q_OR; }
    break;

  case 56:
#line 356 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = Q_AND; }
    break;

  case 57:
#line 357 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = Q_AND; }
    break;

  case 58:
#line 360 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = Q_HOST; }
    break;

  case 59:
#line 361 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = Q_NET; }
    break;

  case 60:
#line 362 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = Q_PORT; }
    break;

  case 61:
#line 363 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = Q_PORTRANGE; }
    break;

  case 62:
#line 366 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = Q_GATEWAY; }
    break;

  case 63:
#line 368 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = Q_LINK; }
    break;

  case 64:
#line 369 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = Q_IP; }
    break;

  case 65:
#line 370 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = Q_ARP; }
    break;

  case 66:
#line 371 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = Q_RARP; }
    break;

  case 67:
#line 372 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = Q_SCTP; }
    break;

  case 68:
#line 373 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = Q_TCP; }
    break;

  case 69:
#line 374 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = Q_UDP; }
    break;

  case 70:
#line 375 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = Q_ICMP; }
    break;

  case 71:
#line 376 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = Q_IGMP; }
    break;

  case 72:
#line 377 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = Q_IGRP; }
    break;

  case 73:
#line 378 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = Q_PIM; }
    break;

  case 74:
#line 379 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = Q_VRRP; }
    break;

  case 75:
#line 380 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = Q_ATALK; }
    break;

  case 76:
#line 381 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = Q_AARP; }
    break;

  case 77:
#line 382 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = Q_DECNET; }
    break;

  case 78:
#line 383 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = Q_LAT; }
    break;

  case 79:
#line 384 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = Q_SCA; }
    break;

  case 80:
#line 385 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = Q_MOPDL; }
    break;

  case 81:
#line 386 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = Q_MOPRC; }
    break;

  case 82:
#line 387 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = Q_IPV6; }
    break;

  case 83:
#line 388 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = Q_ICMPV6; }
    break;

  case 84:
#line 389 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = Q_AH; }
    break;

  case 85:
#line 390 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = Q_ESP; }
    break;

  case 86:
#line 391 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = Q_ISO; }
    break;

  case 87:
#line 392 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = Q_ESIS; }
    break;

  case 88:
#line 393 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = Q_ISIS; }
    break;

  case 89:
#line 394 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = Q_ISIS_L1; }
    break;

  case 90:
#line 395 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = Q_ISIS_L2; }
    break;

  case 91:
#line 396 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = Q_ISIS_IIH; }
    break;

  case 92:
#line 397 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = Q_ISIS_LSP; }
    break;

  case 93:
#line 398 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = Q_ISIS_SNP; }
    break;

  case 94:
#line 399 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = Q_ISIS_PSNP; }
    break;

  case 95:
#line 400 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = Q_ISIS_CSNP; }
    break;

  case 96:
#line 401 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = Q_CLNP; }
    break;

  case 97:
#line 402 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = Q_STP; }
    break;

  case 98:
#line 403 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = Q_IPX; }
    break;

  case 99:
#line 404 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = Q_NETBEUI; }
    break;

  case 100:
#line 405 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = Q_RADIO; }
    break;

  case 101:
#line 407 "../libpcap/GRAMMAR.Y"
    { (yyval.rblk) = gen_broadcast((yyvsp[-1].i)); }
    break;

  case 102:
#line 408 "../libpcap/GRAMMAR.Y"
    { (yyval.rblk) = gen_multicast((yyvsp[-1].i)); }
    break;

  case 103:
#line 409 "../libpcap/GRAMMAR.Y"
    { (yyval.rblk) = gen_less((yyvsp[0].i)); }
    break;

  case 104:
#line 410 "../libpcap/GRAMMAR.Y"
    { (yyval.rblk) = gen_greater((yyvsp[0].i)); }
    break;

  case 105:
#line 411 "../libpcap/GRAMMAR.Y"
    { (yyval.rblk) = gen_byteop((yyvsp[-1].i), (yyvsp[-2].i), (yyvsp[0].i)); }
    break;

  case 106:
#line 412 "../libpcap/GRAMMAR.Y"
    { (yyval.rblk) = gen_inbound(0); }
    break;

  case 107:
#line 413 "../libpcap/GRAMMAR.Y"
    { (yyval.rblk) = gen_inbound(1); }
    break;

  case 108:
#line 414 "../libpcap/GRAMMAR.Y"
    { (yyval.rblk) = gen_vlan((yyvsp[0].i)); }
    break;

  case 109:
#line 415 "../libpcap/GRAMMAR.Y"
    { (yyval.rblk) = gen_vlan(-1); }
    break;

  case 110:
#line 416 "../libpcap/GRAMMAR.Y"
    { (yyval.rblk) = gen_mpls((yyvsp[0].i)); }
    break;

  case 111:
#line 417 "../libpcap/GRAMMAR.Y"
    { (yyval.rblk) = gen_mpls(-1); }
    break;

  case 112:
#line 418 "../libpcap/GRAMMAR.Y"
    { (yyval.rblk) = gen_pppoed(); }
    break;

  case 113:
#line 419 "../libpcap/GRAMMAR.Y"
    { (yyval.rblk) = gen_pppoes(); }
    break;

  case 114:
#line 420 "../libpcap/GRAMMAR.Y"
    { (yyval.rblk) = (yyvsp[0].rblk); }
    break;

  case 115:
#line 421 "../libpcap/GRAMMAR.Y"
    { (yyval.rblk) = (yyvsp[0].rblk); }
    break;

  case 116:
#line 424 "../libpcap/GRAMMAR.Y"
    { (yyval.rblk) = gen_pf_ifname((yyvsp[0].s)); }
    break;

  case 117:
#line 425 "../libpcap/GRAMMAR.Y"
    { (yyval.rblk) = gen_pf_ruleset((yyvsp[0].s)); }
    break;

  case 118:
#line 426 "../libpcap/GRAMMAR.Y"
    { (yyval.rblk) = gen_pf_rnr((yyvsp[0].i)); }
    break;

  case 119:
#line 427 "../libpcap/GRAMMAR.Y"
    { (yyval.rblk) = gen_pf_srnr((yyvsp[0].i)); }
    break;

  case 120:
#line 428 "../libpcap/GRAMMAR.Y"
    { (yyval.rblk) = gen_pf_reason((yyvsp[0].i)); }
    break;

  case 121:
#line 429 "../libpcap/GRAMMAR.Y"
    { (yyval.rblk) = gen_pf_action((yyvsp[0].i)); }
    break;

  case 122:
#line 433 "../libpcap/GRAMMAR.Y"
    { (yyval.rblk) = gen_p80211_type((yyvsp[-2].i) | (yyvsp[0].i),
					IEEE80211_FC0_TYPE_MASK |
					IEEE80211_FC0_SUBTYPE_MASK);
				}
    break;

  case 123:
#line 437 "../libpcap/GRAMMAR.Y"
    { (yyval.rblk) = gen_p80211_type((yyvsp[0].i),
					IEEE80211_FC0_TYPE_MASK);
				}
    break;

  case 124:
#line 440 "../libpcap/GRAMMAR.Y"
    { (yyval.rblk) = gen_p80211_type((yyvsp[0].i),
					IEEE80211_FC0_TYPE_MASK |
					IEEE80211_FC0_SUBTYPE_MASK);
				}
    break;

  case 126:
#line 447 "../libpcap/GRAMMAR.Y"
    { const char *names[] = IEEE80211_TYPE_NAMES;
				  int i, lim;
				  lim = (IEEE80211_FC0_TYPE_MASK >> IEEE80211_FC0_TYPE_SHIFT) + 1;
				  for (i = 0; i < lim; ++i) {
				  	if (pcap_strcasecmp((yyvsp[0].s), names[i]) == 0) {
						(yyval.i) = i << IEEE80211_FC0_TYPE_SHIFT;
						break;
					}
				  }
				  if (i == lim)
				  	bpf_error("unknown 802.11 type name");
				}
    break;

  case 128:
#line 462 "../libpcap/GRAMMAR.Y"
    { const char **names;
				  int i, lim;
				  if ((yyvsp[-2].i) == IEEE80211_FC0_TYPE_MGT)
				  	names = ieee80211_mgt_names;
				  else if ((yyvsp[-2].i) == IEEE80211_FC0_TYPE_CTL)
				  	names = ieee80211_ctl_names;
				  else if ((yyvsp[-2].i) == IEEE80211_FC0_TYPE_DATA)
				  	names = ieee80211_data_names;
				  else
				  	bpf_error("unknown 802.11 type");
				  lim = (IEEE80211_FC0_SUBTYPE_MASK >> IEEE80211_FC0_SUBTYPE_SHIFT) + 1;
				  for (i = 0; i < lim; ++i) {
				  	if (pcap_strcasecmp((yyvsp[0].s), names[i]) == 0) {
						(yyval.i) = i << IEEE80211_FC0_SUBTYPE_SHIFT;
						break;
					}
				  }
				  if (i == lim)
				  	bpf_error("unknown 802.11 subtype name");
				}
    break;

  case 129:
#line 484 "../libpcap/GRAMMAR.Y"
    { const char **sub_names[] = {
					ieee80211_mgt_names,
					ieee80211_ctl_names,
					ieee80211_data_names
				  };
				  int i, j, lim, sub_lim;
				  sub_lim = sizeof(sub_names) / sizeof(sub_names[0]);
				  lim = (IEEE80211_FC0_SUBTYPE_MASK >> IEEE80211_FC0_SUBTYPE_SHIFT) + 1;
				  for (i = 0; i < sub_lim; ++i) {
				  	const char **names = sub_names[i];
				  	for (j = 0; j < lim; ++j) {
						if (pcap_strcasecmp((yyvsp[0].s), names[j]) == 0)
							break;
					}
					if (j != lim) {
						(yyval.i) = (i << IEEE80211_FC0_TYPE_SHIFT) |
						     (j << IEEE80211_FC0_SUBTYPE_SHIFT);
						break;
					}
				  }
				  if (i == sub_lim)
				  	bpf_error("unknown 802.11 subtype name");
				}
    break;

  case 130:
#line 509 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = (yyvsp[0].i); }
    break;

  case 131:
#line 510 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = pfreason_to_num((yyvsp[0].s)); }
    break;

  case 132:
#line 513 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = pfaction_to_num((yyvsp[0].s)); }
    break;

  case 133:
#line 516 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = BPF_JGT; }
    break;

  case 134:
#line 517 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = BPF_JGE; }
    break;

  case 135:
#line 518 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = BPF_JEQ; }
    break;

  case 136:
#line 520 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = BPF_JGT; }
    break;

  case 137:
#line 521 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = BPF_JGE; }
    break;

  case 138:
#line 522 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = BPF_JEQ; }
    break;

  case 139:
#line 524 "../libpcap/GRAMMAR.Y"
    { (yyval.a) = gen_loadi((yyvsp[0].i)); }
    break;

  case 141:
#line 527 "../libpcap/GRAMMAR.Y"
    { (yyval.a) = gen_load((yyvsp[-3].i), (yyvsp[-1].a), 1); }
    break;

  case 142:
#line 528 "../libpcap/GRAMMAR.Y"
    { (yyval.a) = gen_load((yyvsp[-5].i), (yyvsp[-3].a), (yyvsp[-1].i)); }
    break;

  case 143:
#line 529 "../libpcap/GRAMMAR.Y"
    { (yyval.a) = gen_arth(BPF_ADD, (yyvsp[-2].a), (yyvsp[0].a)); }
    break;

  case 144:
#line 530 "../libpcap/GRAMMAR.Y"
    { (yyval.a) = gen_arth(BPF_SUB, (yyvsp[-2].a), (yyvsp[0].a)); }
    break;

  case 145:
#line 531 "../libpcap/GRAMMAR.Y"
    { (yyval.a) = gen_arth(BPF_MUL, (yyvsp[-2].a), (yyvsp[0].a)); }
    break;

  case 146:
#line 532 "../libpcap/GRAMMAR.Y"
    { (yyval.a) = gen_arth(BPF_DIV, (yyvsp[-2].a), (yyvsp[0].a)); }
    break;

  case 147:
#line 533 "../libpcap/GRAMMAR.Y"
    { (yyval.a) = gen_arth(BPF_AND, (yyvsp[-2].a), (yyvsp[0].a)); }
    break;

  case 148:
#line 534 "../libpcap/GRAMMAR.Y"
    { (yyval.a) = gen_arth(BPF_OR, (yyvsp[-2].a), (yyvsp[0].a)); }
    break;

  case 149:
#line 535 "../libpcap/GRAMMAR.Y"
    { (yyval.a) = gen_arth(BPF_LSH, (yyvsp[-2].a), (yyvsp[0].a)); }
    break;

  case 150:
#line 536 "../libpcap/GRAMMAR.Y"
    { (yyval.a) = gen_arth(BPF_RSH, (yyvsp[-2].a), (yyvsp[0].a)); }
    break;

  case 151:
#line 537 "../libpcap/GRAMMAR.Y"
    { (yyval.a) = gen_neg((yyvsp[0].a)); }
    break;

  case 152:
#line 538 "../libpcap/GRAMMAR.Y"
    { (yyval.a) = (yyvsp[-1].a); }
    break;

  case 153:
#line 539 "../libpcap/GRAMMAR.Y"
    { (yyval.a) = gen_loadlen(); }
    break;

  case 154:
#line 541 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = '&'; }
    break;

  case 155:
#line 542 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = '|'; }
    break;

  case 156:
#line 543 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = '<'; }
    break;

  case 157:
#line 544 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = '>'; }
    break;

  case 158:
#line 545 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = '='; }
    break;

  case 160:
#line 548 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = (yyvsp[-1].i); }
    break;

  case 161:
#line 550 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = A_LANE; }
    break;

  case 162:
#line 551 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = A_LLC; }
    break;

  case 163:
#line 552 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = A_METAC;	}
    break;

  case 164:
#line 553 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = A_BCC; }
    break;

  case 165:
#line 554 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = A_OAMF4EC; }
    break;

  case 166:
#line 555 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = A_OAMF4SC; }
    break;

  case 167:
#line 556 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = A_SC; }
    break;

  case 168:
#line 557 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = A_ILMIC; }
    break;

  case 169:
#line 559 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = A_OAM; }
    break;

  case 170:
#line 560 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = A_OAMF4; }
    break;

  case 171:
#line 561 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = A_CONNECTMSG; }
    break;

  case 172:
#line 562 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = A_METACONNECT; }
    break;

  case 173:
#line 565 "../libpcap/GRAMMAR.Y"
    { (yyval.blk).atmfieldtype = A_VPI; }
    break;

  case 174:
#line 566 "../libpcap/GRAMMAR.Y"
    { (yyval.blk).atmfieldtype = A_VCI; }
    break;

  case 176:
#line 569 "../libpcap/GRAMMAR.Y"
    { (yyval.blk).b = gen_atmfield_code((yyvsp[-2].blk).atmfieldtype, (bpf_int32)(yyvsp[0].i), (bpf_u_int32)(yyvsp[-1].i), 0); }
    break;

  case 177:
#line 570 "../libpcap/GRAMMAR.Y"
    { (yyval.blk).b = gen_atmfield_code((yyvsp[-2].blk).atmfieldtype, (bpf_int32)(yyvsp[0].i), (bpf_u_int32)(yyvsp[-1].i), 1); }
    break;

  case 178:
#line 571 "../libpcap/GRAMMAR.Y"
    { (yyval.blk).b = (yyvsp[-1].blk).b; (yyval.blk).q = qerr; }
    break;

  case 179:
#line 573 "../libpcap/GRAMMAR.Y"
    {
	(yyval.blk).atmfieldtype = (yyvsp[-1].blk).atmfieldtype;
	if ((yyval.blk).atmfieldtype == A_VPI ||
	    (yyval.blk).atmfieldtype == A_VCI)
		(yyval.blk).b = gen_atmfield_code((yyval.blk).atmfieldtype, (bpf_int32) (yyvsp[0].i), BPF_JEQ, 0);
	}
    break;

  case 181:
#line 581 "../libpcap/GRAMMAR.Y"
    { gen_or((yyvsp[-2].blk).b, (yyvsp[0].blk).b); (yyval.blk) = (yyvsp[0].blk); }
    break;

  case 182:
#line 584 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = M_FISU; }
    break;

  case 183:
#line 585 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = M_LSSU; }
    break;

  case 184:
#line 586 "../libpcap/GRAMMAR.Y"
    { (yyval.i) = M_MSU; }
    break;

  case 185:
#line 589 "../libpcap/GRAMMAR.Y"
    { (yyval.blk).mtp3fieldtype = M_SIO; }
    break;

  case 186:
#line 590 "../libpcap/GRAMMAR.Y"
    { (yyval.blk).mtp3fieldtype = M_OPC; }
    break;

  case 187:
#line 591 "../libpcap/GRAMMAR.Y"
    { (yyval.blk).mtp3fieldtype = M_DPC; }
    break;

  case 188:
#line 592 "../libpcap/GRAMMAR.Y"
    { (yyval.blk).mtp3fieldtype = M_SLS; }
    break;

  case 190:
#line 595 "../libpcap/GRAMMAR.Y"
    { (yyval.blk).b = gen_mtp3field_code((yyvsp[-2].blk).mtp3fieldtype, (u_int)(yyvsp[0].i), (u_int)(yyvsp[-1].i), 0); }
    break;

  case 191:
#line 596 "../libpcap/GRAMMAR.Y"
    { (yyval.blk).b = gen_mtp3field_code((yyvsp[-2].blk).mtp3fieldtype, (u_int)(yyvsp[0].i), (u_int)(yyvsp[-1].i), 1); }
    break;

  case 192:
#line 597 "../libpcap/GRAMMAR.Y"
    { (yyval.blk).b = (yyvsp[-1].blk).b; (yyval.blk).q = qerr; }
    break;

  case 193:
#line 599 "../libpcap/GRAMMAR.Y"
    {
	(yyval.blk).mtp3fieldtype = (yyvsp[-1].blk).mtp3fieldtype;
	if ((yyval.blk).mtp3fieldtype == M_SIO ||
	    (yyval.blk).mtp3fieldtype == M_OPC ||
	    (yyval.blk).mtp3fieldtype == M_DPC ||
	    (yyval.blk).mtp3fieldtype == M_SLS )
		(yyval.blk).b = gen_mtp3field_code((yyval.blk).mtp3fieldtype, (u_int) (yyvsp[0].i), BPF_JEQ, 0);
	}
    break;

  case 195:
#line 609 "../libpcap/GRAMMAR.Y"
    { gen_or((yyvsp[-2].blk).b, (yyvsp[0].blk).b); (yyval.blk) = (yyvsp[0].blk); }
    break;


      default: break;
    }

/* Line 1126 of yacc.c.  */
#line 2856 "y.tab.c"

  yyvsp -= yylen;
  yyssp -= yylen;


  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;


  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if YYERROR_VERBOSE
      yyn = yypact[yystate];

      if (YYPACT_NINF < yyn && yyn < YYLAST)
	{
	  int yytype = YYTRANSLATE (yychar);
	  YYSIZE_T yysize0 = yytnamerr (0, yytname[yytype]);
	  YYSIZE_T yysize = yysize0;
	  YYSIZE_T yysize1;
	  int yysize_overflow = 0;
	  char *yymsg = 0;
#	  define YYERROR_VERBOSE_ARGS_MAXIMUM 5
	  char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
	  int yyx;

#if 0
	  /* This is so xgettext sees the translatable formats that are
	     constructed on the fly.  */
	  YY_("syntax error, unexpected %s");
	  YY_("syntax error, unexpected %s, expecting %s");
	  YY_("syntax error, unexpected %s, expecting %s or %s");
	  YY_("syntax error, unexpected %s, expecting %s or %s or %s");
	  YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s");
#endif
	  char *yyfmt;
	  char const *yyf;
	  static char const yyunexpected[] = "syntax error, unexpected %s";
	  static char const yyexpecting[] = ", expecting %s";
	  static char const yyor[] = " or %s";
	  char yyformat[sizeof yyunexpected
			+ sizeof yyexpecting - 1
			+ ((YYERROR_VERBOSE_ARGS_MAXIMUM - 2)
			   * (sizeof yyor - 1))];
	  char const *yyprefix = yyexpecting;

	  /* Start YYX at -YYN if negative to avoid negative indexes in
	     YYCHECK.  */
	  int yyxbegin = yyn < 0 ? -yyn : 0;

	  /* Stay within bounds of both yycheck and yytname.  */
	  int yychecklim = YYLAST - yyn;
	  int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
	  int yycount = 1;

	  yyarg[0] = yytname[yytype];
	  yyfmt = yystpcpy (yyformat, yyunexpected);

	  for (yyx = yyxbegin; yyx < yyxend; ++yyx)
	    if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
	      {
		if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
		  {
		    yycount = 1;
		    yysize = yysize0;
		    yyformat[sizeof yyunexpected - 1] = '\0';
		    break;
		  }
		yyarg[yycount++] = yytname[yyx];
		yysize1 = yysize + yytnamerr (0, yytname[yyx]);
		yysize_overflow |= yysize1 < yysize;
		yysize = yysize1;
		yyfmt = yystpcpy (yyfmt, yyprefix);
		yyprefix = yyor;
	      }

	  yyf = YY_(yyformat);
	  yysize1 = yysize + yystrlen (yyf);
	  yysize_overflow |= yysize1 < yysize;
	  yysize = yysize1;

	  if (!yysize_overflow && yysize <= YYSTACK_ALLOC_MAXIMUM)
	    yymsg = (char *) YYSTACK_ALLOC (yysize);
	  if (yymsg)
	    {
	      /* Avoid sprintf, as that infringes on the user's name space.
		 Don't have undefined behavior even if the translation
		 produced a string with the wrong number of "%s"s.  */
	      char *yyp = yymsg;
	      int yyi = 0;
	      while ((*yyp = *yyf))
		{
		  if (*yyp == '%' && yyf[1] == 's' && yyi < yycount)
		    {
		      yyp += yytnamerr (yyp, yyarg[yyi++]);
		      yyf += 2;
		    }
		  else
		    {
		      yyp++;
		      yyf++;
		    }
		}
	      yyerror (yymsg);
	      YYSTACK_FREE (yymsg);
	    }
	  else
	    {
	      yyerror (YY_("syntax error"));
	      goto yyexhaustedlab;
	    }
	}
      else
#endif /* YYERROR_VERBOSE */
	yyerror (YY_("syntax error"));
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse look-ahead token after an
	 error, discard it.  */

      if (yychar <= YYEOF)
        {
	  /* Return failure if at end of input.  */
	  if (yychar == YYEOF)
	    YYABORT;
        }
      else
	{
	  yydestruct ("Error: discarding", yytoken, &yylval);
	  yychar = YYEMPTY;
	}
    }

  /* Else will try to reuse look-ahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (0)
     goto yyerrorlab;

yyvsp -= yylen;
  yyssp -= yylen;
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (yyn != YYPACT_NINF)
	{
	  yyn += YYTERROR;
	  if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
	    {
	      yyn = yytable[yyn];
	      if (0 < yyn)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
	YYABORT;


      yydestruct ("Error: popping", yystos[yystate], yyvsp);
      YYPOPSTACK;
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  *++yyvsp = yylval;


  /* Shift the error token. */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#ifndef yyoverflow
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEOF && yychar != YYEMPTY)
     yydestruct ("Cleanup: discarding lookahead",
		 yytoken, &yylval);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
		  yystos[*yyssp], yyvsp);
      YYPOPSTACK;
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
  return yyresult;
}


#line 611 "../libpcap/GRAMMAR.Y"


